#import "Login.h"
#import "SaveData.h"
#import <AdSupport/ASIdentifierManager.h>

NSString *Value;
NSString *VvGg;

@implementation Login
+ (void)load {
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
Value = [NSString stringWithFormat:@"Vages.%@", [[CHKeychain GetUUID] stringByReplacingOccurrencesOfString:@"-" withString:@""]];
NSMutableDictionary *Vages = (NSMutableDictionary *)[CHKeychain load:@"Vages"];
VvGg = [Vages objectForKey:Value];
if (VvGg == 0) {
[CHKeychain Set];
} else {
[Login Lifand:true];
}});
}

+ (void)Lifand:(bool)Swspd {
if (Swspd) {
// NSString *GetKey = @"Testing";
NSString *URLString = [NSString stringWithFormat:@"https://its0shoot.com/Server/Status.php?Get1=%@&Get2=%@&Get3=%@&Get4=%@&Get5=1", [CHKeychain GetUUID], VvGg, [CHKeychain GetBundle], [CHKeychain GetName]];
if ([[[NSString alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:URLString]] encoding:NSUTF8StringEncoding] isEqualToString:@""]) {
[CHKeychain SetAlert:false Name:@"Vages" Text:@"Code Not Found"];
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
[CHKeychain Set];
});
} else {
NSData *Pqnxjw = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:URLString]];
NSDictionary *Qdjdie = [NSJSONSerialization JSONObjectWithData:Pqnxjw options:0 error:nil];
NSData *Lwndpw = [[self Paint:[Qdjdie objectForKey:@"1"] Qaint:[Qdjdie objectForKey:@"0"]] dataUsingEncoding:NSUTF8StringEncoding];
NSDictionary *Peldbe = [NSJSONSerialization JSONObjectWithData:Lwndpw options:0 error:nil];
if ([[Peldbe objectForKey:@"5"] isEqualToString:@"1"]) {
[CHKeychain SetAlert:true Name:@"Vages" Text:Peldbe[@"6"]];
} else if ([[Peldbe objectForKey:@"5"] isEqualToString:@"0"] && [[Peldbe objectForKey:@"1"] isEqualToString:@"1"] && [[Peldbe objectForKey:@"0"] isEqualToString:[CHKeychain GetUUID]]) {
NSData *Pqnxjw2 = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:Peldbe[@"7"]]];
NSDictionary *Qdjdie2 = [NSJSONSerialization JSONObjectWithData:Pqnxjw2 options:0 error:nil];
NSData *Lwndpw2 = [[self Paint:[Qdjdie2 objectForKey:@"1"] Qaint:[Qdjdie2 objectForKey:@"0"]] dataUsingEncoding:NSUTF8StringEncoding];
NSDictionary *Peldbe2 = [NSJSONSerialization JSONObjectWithData:Lwndpw2 options:0 error:nil];
if ([[Peldbe objectForKey:@"4"] isEqualToString:URLString] && [[Peldbe2 objectForKey:@"4"] isEqualToString:URLString] && [[Peldbe objectForKey:@"7"] isEqualToString:Peldbe2[@"7"]] && [[Peldbe2 objectForKey:@"5"] isEqualToString:@"0"] && [[Peldbe2 objectForKey:@"1"] isEqualToString:@"1"] && [[Peldbe2 objectForKey:@"0"] isEqualToString:[CHKeychain GetUUID]]) {
[CHKeychain SetAlert:false Name:@"Vages" Text:[NSString stringWithFormat:@"%@\n%@", Peldbe[@"2"], Peldbe[@"3"]]];
// Start Menu
} else {
[CHKeychain SetAlert:true Name:@"Vages" Text:@"FuckYou"];
}
} else {
[CHKeychain SetAlert:false Name:@"Vages" Text:Peldbe[@"2"]];
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
[CHKeychain Set];
});
}
}

} else {

UIPasteboard *GetPaste = [UIPasteboard generalPasteboard];
NSString *GetKey = GetPaste.string;
// NSString *GetKey = @"Testing";
NSString *URLString = [NSString stringWithFormat:@"https://its0shoot.com/Server/Status.php?Get1=%@&Get2=%@&Get3=%@&Get4=%@&Get5=1", [CHKeychain GetUUID], GetKey, [CHKeychain GetBundle], [CHKeychain GetName]];
if ([[[NSString alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:URLString]] encoding:NSUTF8StringEncoding] isEqualToString:@""]) {
[CHKeychain SetAlert:false Name:@"Vages" Text:@"Code Not Found"];
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
[CHKeychain Set];
});
} else {
NSData *Pqnxjw = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:URLString]];
NSDictionary *Qdjdie = [NSJSONSerialization JSONObjectWithData:Pqnxjw options:0 error:nil];
NSData *Lwndpw = [[self Paint:[Qdjdie objectForKey:@"1"] Qaint:[Qdjdie objectForKey:@"0"]] dataUsingEncoding:NSUTF8StringEncoding];
NSDictionary *Peldbe = [NSJSONSerialization JSONObjectWithData:Lwndpw options:0 error:nil];
if ([[Peldbe objectForKey:@"5"] isEqualToString:@"1"]) {
[CHKeychain SetAlert:true Name:@"Vages" Text:Peldbe[@"6"]];
} else if ([[Peldbe objectForKey:@"5"] isEqualToString:@"0"] && [[Peldbe objectForKey:@"1"] isEqualToString:@"1"] && [[Peldbe objectForKey:@"0"] isEqualToString:[CHKeychain GetUUID]]) {
NSData *Pqnxjw2 = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:Peldbe[@"7"]]];
NSDictionary *Qdjdie2 = [NSJSONSerialization JSONObjectWithData:Pqnxjw2 options:0 error:nil];
NSData *Lwndpw2 = [[self Paint:[Qdjdie2 objectForKey:@"1"] Qaint:[Qdjdie2 objectForKey:@"0"]] dataUsingEncoding:NSUTF8StringEncoding];
NSDictionary *Peldbe2 = [NSJSONSerialization JSONObjectWithData:Lwndpw2 options:0 error:nil];
if ([[Peldbe objectForKey:@"4"] isEqualToString:URLString] && [[Peldbe2 objectForKey:@"4"] isEqualToString:URLString] && [[Peldbe objectForKey:@"7"] isEqualToString:Peldbe2[@"7"]] && [[Peldbe2 objectForKey:@"5"] isEqualToString:@"0"] && [[Peldbe2 objectForKey:@"1"] isEqualToString:@"1"] && [[Peldbe2 objectForKey:@"0"] isEqualToString:[CHKeychain GetUUID]]) {
NSMutableDictionary *Vages = [NSMutableDictionary dictionary];
[Vages setObject:GetKey forKey:Value];
[CHKeychain save:@"Vages" data:Vages];
[CHKeychain SetAlert:true Name:@"Vages" Text:[NSString stringWithFormat:@"%@\n%@\n سيتم اخراجك من اللعبة اعد الدخول", Peldbe[@"2"], Peldbe[@"3"]]];
} else {
[CHKeychain SetAlert:true Name:@"Vages" Text:@"FuckYou"];
}
} else {
[CHKeychain SetAlert:false Name:@"Vages" Text:Peldbe[@"2"]];
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
[CHKeychain Set];
});
}
}
}
}

+ (NSString *)Paint:(NSString *)Paint Qaint:(NSString *)Qaint {
return [[self Qaint:[self Qaint:[self Qaint:[self Qaint:[self Qaint:Paint]]]]] stringByReplacingOccurrencesOfString:[self Qaint:[self Qaint:[self Qaint:[self Qaint:[self Qaint:Qaint]]]]] withString:@""];
}

+ (NSString *)Qaint:(NSString *)Qaint {
NSData *Nsjdvw = [[NSData alloc] initWithBase64EncodedString:Qaint options:0];
return [[NSString alloc] initWithData:Nsjdvw encoding:NSUTF8StringEncoding];
}
@end
