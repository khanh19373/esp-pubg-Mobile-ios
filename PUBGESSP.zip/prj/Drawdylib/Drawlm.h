#import <UIKit/UIKit.h>
#import "JFCommon.h"
#import <vector>
#import <string>

#import <Foundation/Foundation.h>
//
//  Created BY ？和 on 2021/6/31
//  B.Y QQ  3556674785
//  仅供学习交流，请在24小时内卸载￼

NS_ASSUME_NONNULL_BEGIN

@interface JFPlayer : NSObject

@property (nonatomic, assign) long base;
@property (nonatomic, assign) int teamNo;
@property (nonatomic, assign) bool isAI;
@property (nonatomic) std::string name;
@property (nonatomic) std::string flag;

@property (nonatomic, assign) UInt32 playerKey;
@property (nonatomic, assign) UInt32 ME;
@property (nonatomic, assign) int isArm;
@property (nonatomic,  assign) uint64_t  state;
@property (nonatomic, assign) int hp;
@property (nonatomic, assign) float ActorRender;
@property (nonatomic, assign) float lastRender;

@property (nonatomic, assign) int maxHp;
@property (nonatomic, assign) int signalHP;
@property (nonatomic, assign) int signalHPMax;
@property (nonatomic, assign) bool isFallDown;
@property (nonatomic, assign) bool isDead;
@property (nonatomic, assign) bool isVisible;
@property (nonatomic) Vector3 worldPos;

@property (nonatomic, assign) PlayerType type;
@property (nonatomic) Vector3 BoxSphereBounds;
@property (nonatomic, assign) CGRect box;
@property (nonatomic, assign) CGRect box2;

@property (nonatomic, assign) int distance;
@property (nonatomic, assign) bool isBestAimTarget;

@property (nonatomic) BoneData boneData;
@property (nonatomic) BoneVisibleData boneVisibleData;

@end

NS_ASSUME_NONNULL_END
