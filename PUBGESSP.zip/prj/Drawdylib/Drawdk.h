#import <UIKit/UIKit.h>
#import "JFCommon.h"
#import <string>
//
//  Created BY ？和 on 2021/6/31
//  B.Y QQ  3556674785
//  仅供学习交流，请在24小时内卸载￼


NS_ASSUME_NONNULL_BEGIN

@interface JFProps : NSObject
@property (nonatomic, assign) long base;
@property (nonatomic) std::string name;
@property (nonatomic, assign) PropsType type;
@property (nonatomic) Vector3 worldPos;
@property (nonatomic, assign) Vector2 screenPos;
@property (nonatomic, assign) int distance;
@property (nonatomic) std::string flag;

@end

NS_ASSUME_NONNULL_END
