//
//  FPSDisplay.h
//  ShadowTrackerExtra
//
//  Created by 佚名 on 2020/3/16.
//  Copyright © 2020 佚名. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface FPSDisplay : NSObject
+ (instancetype)shareFPSDisplay;
@end
