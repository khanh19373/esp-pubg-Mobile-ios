#import <UIKit/UIKit.h>
#import "JFFloatingMenuView.h"
//
//  Created BY ？和 on 2021/6/31
//  B.Y QQ  3556674785
//  仅供学习交流，请在24小时内卸载￼


NS_ASSUME_NONNULL_BEGIN

@interface JFOverlayView : UIView

@property (nonatomic, assign) bool isStartTimer;
@property (nonatomic, assign) bool isShowMenu;
@property (nonatomic, assign) bool isLineEsp;
@property (nonatomic, assign) bool isBoxEsp;

@property (nonatomic, assign) bool FastSwitchWeapon;
@property (nonatomic, assign) bool isHpBarEsp;
@property (nonatomic, assign) bool isTextEsp;
@property (nonatomic, assign) bool isBoneEsp;
@property (nonatomic, assign) bool isTeamMateEsp;
@property (nonatomic, assign) int espDistance;
@property (nonatomic, assign) bool Autofire;
@property (nonatomic, assign) bool isInstanthit;//SpeedFire
@property (nonatomic, assign) bool SpeedFire;//
@property (nonatomic, assign) bool NoSpread;//NoGravity;
@property (nonatomic, assign) bool isAimbot;
@property (nonatomic, assign) bool isAimbotS;
@property (nonatomic, assign) bool isAimbotF;
@property (nonatomic, assign) bool isAimbotA;

@property (nonatomic, assign) bool aimlockp;
@property (nonatomic, assign) bool nolockb;


@property (nonatomic, assign) bool isBulletSpeed;//
@property (nonatomic, assign) bool NoGravity;//
@property (nonatomic, assign) bool isAimbotscope;
@property (nonatomic, assign) bool ISdawko;
@property (nonatomic, assign) bool anti;
@property (nonatomic, assign) bool isBulletTrack;
@property (nonatomic, assign) bool isNorecoil;
@property (nonatomic, assign) bool isNearDeathNotAim;
@property (nonatomic, assign) bool isAINotAim;
@property (nonatomic, assign) bool isAim100;
@property (nonatomic, assign) int aimbotPart;
@property (nonatomic, assign) int amichest;
@property (nonatomic, assign) int aimbotRadius;//aimbotPart1 BoxWith BPc Color xiongbu1
@property (nonatomic, assign) bool Anticheat;
@property (nonatomic, assign) bool Antich;

//@property (nonatomic, assign) bool Color; amichest

@property (nonatomic, assign) bool isShowProps;
@property (nonatomic, assign) bool isShowPropsVehicle;
@property (nonatomic, assign) bool isShowPropsWeapon;
@property (nonatomic, assign) bool isShowPropsArmor;
@property (nonatomic, assign) bool isShowPropsSight;
@property (nonatomic, assign) bool isShowPropsAccessory;
@property (nonatomic, assign) bool isShowPropsBullet;
@property (nonatomic, assign) bool isShowPropsDrug;
@property (nonatomic, assign) bool BoxWith;
@property (nonatomic, assign) bool BPc;
@property (nonatomic, assign) bool Pistol;
@property (nonatomic, assign) bool isShowPropsEarlyWarning;
@property (nonatomic, assign) int propsDistance;

@end

NS_ASSUME_NONNULL_END
