//
//  anti.m
//  DrawHM
//
//  Created by fahad on 25.06.22.
//

#import <Foundation/Foundation.h>

UIWindow *mainWindow;
UILabel *Ttime;


    
    
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
         
          

            
          UIWindow*mainWindow;
            [[[[UIApplication sharedApplication] windows]lastObject] addSubview:mainWindow];

               [DREM hala_Patch:@"CY8IO4ycwAZaSuGjXWYZZQ==" : @"7X9cAmcgUbQw460s74gsyA=="];

               [DREM hala_Patch:@"A0Yoy0KUc5YrfpjESTwuGg==" : @"7X9cAmcgUbQw460s74gsyA=="];

               [DREM hala_Patch:@"RMrO+SF2+S+f4vu+LjW1MA==" : @"7X9cAmcgUbQw460s74gsyA=="];


          Ttime = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width / 4 - 5, 5, [UIScreen mainScreen].bounds.size.width / 2  + 10, 20)];
                     Ttime.font = [UIFont fontWithName:@"LaoSangamMN" size:20.0];
                     Ttime.layer.cornerRadius = 15;
                     Ttime.textAlignment = NSTextAlignmentCenter;
                     Ttime.layer.masksToBounds = true;
                     Ttime.text = [NSString stringWithFormat:@"IPlay - Server"];
               Ttime.textColor = [UIColor redColor];
               [mainWindow addSubview:Ttime];

      
      });
    
    

