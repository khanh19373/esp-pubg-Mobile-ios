#import "Drawzb.h"
#import <mach-o/dyld.h>
#import <mach/mach.h>
#import <dlfcn.h>
#import <stdio.h>
#import <string>
#import "JFCommon.h"
#import "Drawlm.h"
#import "JFPlayerPool.h"
#import "Drawdk.h"
#import "JFPropsPool.h"
#import "utf.h"
#define IM_PI                   3.14159265358979323846f
#define RAD2DEG( x )  ( (float)(x) * (float)(180.f / IM_PI) )
#define DEG2RAD( x ) ( (float)(x) * (float)(IM_PI / 180.f) )

#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
UIImage* A1Image;

FRotator Rotation;
using namespace std;
uintptr_t Vtabel;




kaddr module;
kaddr localPlayerController;
kaddr controlRotation;
MinimalViewInfo POV;
kaddr ownerShootWeapon;
kaddr emeCurrentWeapon;
int ShootWeaponid = 0;
int curammo =0;
int recoil;
bool isScoopOpen;

namespace Offsets {




kaddr LineOfSightTo_Func = ?????;
}

bool IsValidAddress(kaddr addr) {
return addr > 0x100000000 && addr < 0x2000000000;
}

bool _read(kaddr addr, void *buffer, int len)
{
if (!IsValidAddress(addr)) return false;
vm_size_t size = 0;
kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)addr, len, (vm_address_t)buffer, &size);
if(error != KERN_SUCCESS || size != len)
{
return false;
}
return true;
}

bool _write(kaddr addr, void *buffer, int len)
{
if (!IsValidAddress(addr)) return false;
kern_return_t error = vm_write(mach_task_self(), (vm_address_t)addr, (vm_offset_t)buffer, (mach_msg_type_number_t)len);
if(error != KERN_SUCCESS)
{
return false;
}
return true;
}

kaddr GetRealOffset(kaddr offset) {
if (module == 0) {
return 0;
}
return (module + offset);
}

template<typename T> T Read(kaddr address) {
T data;
_read(address, reinterpret_cast<void *>(&data), sizeof(T));
return data;
}

template<typename T> void Write(kaddr address, T data) {
_write(address, reinterpret_cast<void *>(&data), sizeof(T));
}

template<typename T> T *ReadArr(kaddr address, unsigned int size) {
T data[size];
T *ptr = data;
_read(address, reinterpret_cast<void *>(ptr), (sizeof(T) * size));
return ptr;
}

string ReadStr2(kaddr address, unsigned int size) {
string name(size, '\0');
_read(address, (void *) name.data(), size * sizeof(char));
name.shrink_to_fit();
return name;
}

kaddr GetPtr(kaddr address) {
return Read<kaddr>(address);
}


long uworld() {


return reinterpret_cast<long(__fastcall*)(long)>(GetRealOffset(????))(GetRealOffset(?????));
};

long fast2() {


return  reinterpret_cast<long(__fastcall*)(long)>(GetRealOffset(????))(GetRealOffset(????????????));




};
string getUEString(kaddr address) {
unsigned int MAX_SIZE = 100;

string uestring(ReadStr2(address, MAX_SIZE));
uestring.shrink_to_fit();

return uestring;
}

string GetFName(kaddr actorAddress) {
UInt32 FNameID = Read<UInt32>(actorAddress + 0x18);
kaddr TNameEntryArray = fast2();

kaddr FNameEntryArr = GetPtr(TNameEntryArray + ((FNameID / 0x4000) * 8));
kaddr FNameEntry = GetPtr(FNameEntryArr + ((FNameID % 0x4000) * 8));
return getUEString(FNameEntry + 0xc);
}

#pragma mark - 字符串工具函数
bool isEqual(string s1, const char* check) {
string s2(check);
return (s1 == s2);
}

bool isEqual(string s1, string s2) {
return (s1 == s2);
}

bool isContain(string str, const char* check) {
size_t found = str.find(check);
return (found != string::npos);
}



bool isPlayer(string FName) {
return isContain(FName, "BP_PlayerPawn") || isContain(FName, "?????????");
}


string getVehicleWithFName(string FName) {
if (isContain(FName, "VH_Scooter_")) {
return "Scooter";
}
if (isContain(FName, "VH_Motorcycle_")) {
return "Motorcycle";
}
if (isContain(FName, "VH_MotorcycleCart_")) {
return "MotorcycleCart";
}
if (isContain(FName, "BP_VH_Tuk_")) {
return "TukTuk";
}
if (isContain(FName, "BP_VH_Buggy_")) {
return "Buggy";
}
if (isContain(FName, "PickUp_0")) {
return "PickUp_0";
}
if (isContain(FName, "Mirado_")) {
return "Mirado";
}
if (isContain(FName, "VH_Dacia_")) {
return "Dacia";
}
if (isContain(FName, "AquaRail_")) {
return "AquaRail";
}
if (isContain(FName, "BP_VH_CoupeRB_")) {
return "CoupeRB";
}
if (isContain(FName, "VH_MiniBus_")) {
return "MiniBus";
}
if (isContain(FName, "VH_BRDM_")) {
return "BRDM";
}
if (isContain(FName, "VH_UAZ")) {
return "UAZ";
}


return "";
}


string getWeaponWithFName(string FName) {
if (isContain(FName, "BP_Rifle_VAL_Wrapper_C")) {
return "VAL";
}
if (isContain(FName, "BP_Rifle_AKM_Wrapper_C")) {
return "AKM";
}
if (isContain(FName, "BP_Rifle_M416_Wrapper_C")) {
return "M416";
}
if (isContain(FName, "BP_Rifle_SCAR_Wrapper_C")) {
return "SCAR-L";
}
if (isContain(FName, "BP_Rifle_QBZ_Wrapper_C")) {
return "QBZ";
}
if (isContain(FName, "BP_Sniper_Kar98k_Wrapper_C")) {
return "Kar98k";
}
if (isContain(FName, "BP_Sniper_Mini14_Wrapper_C")) {
return "Mini14";
}
if (isContain(FName, "BP_Rifle_M762_Wrapper_C")) {
return "M762";
}
if (isContain(FName, "BP_Rifle_M762_Wrapper_C")) {
return "M762";
}
if (isContain(FName, "BP_MachineGun_Vector_Wrapper_C")) {
return "Vector";
}
if (isContain(FName, "BP_MachineGun_Uzi_Wrapper_C")) {
return "Uzi";
}
if (isContain(FName, "BP_MachineGun_TommyGun_Wrapper_C")) {
return "TommyGun";
}
if (isContain(FName, "BP_MachineGun_UMP9_Wrapper_C")) {
return "UMP9";
}
if (isContain(FName, "BP_Sniper_AWM_C")) {
return "AWM";
}
if (isContain(FName, "BP_Sniper_AWM_Wrapper_C")) {
return "AWM";
}
if (isContain(FName, "BP_Sniper_M24_Wrapper_C")) {
return "M24";
}
if (isContain(FName, "BP_Sniper_Kar98k_Wrapper_C")) {
return "Kar98k";
}
return "";
}

string getArmorWithFName(string FName) {
if (isContain(FName, "PickUp_BP_Helmet_Lv2_C") || isEqual(FName, "PickUp_BP_Helmet_Lv2_A_C") || isEqual(FName, "PickUp_BP_Helmet_Lv2_B_C")) {
return "Mũ_Lv2";
}
if (isContain(FName, "PickUp_BP_Armor_Lv2_C") || isEqual(FName, "PickUp_BP_Armor_Lv2_A_C") || isEqual(FName, "PickUp_BP_Armor_Lv2_B_C")) {
return "Áo Giáp_Lv2";
}
if (isContain(FName, "PickUp_BP_Bag_Lv2_C") || isEqual(FName, "PickUp_BP_Bag_Lv2_A_C") || isEqual(FName, "PickUp_BP_Bag_Lv2_B_C")) {
return "Balo_Lv2";
}
if (isContain(FName, "PickUp_BP_Helmet_Lv3_C") || isEqual(FName, "PickUp_BP_Helmet_Lv3_A_C") || isEqual(FName, "PickUp_BP_Helmet_Lv3_B_C")) {
return "Mũ_Lv3";
}
if (isContain(FName, "PickUp_BP_Armor_Lv3_C") || isEqual(FName, "PickUp_BP_Armor_Lv3_A_C") || isEqual(FName, "PickUp_BP_Armor_Lv3_B_C")) {
return "Áo Giáp_Lv3";
}
return "";
}


string getSightWithFName(string FName) {
if (isContain(FName, "BP_MZJ_3X_Pickup_C")) {
return "Ống Ngắm 3X";//PickUpListWrapperActor
}
if (isContain(FName, "BP_MZJ_4X_Pickup_C")) {
return "Ống Ngắm 4X";
}

if (isContain(FName, "BP_MZJ_6X_Pickup_C")) {
return "Ống Ngắm 6X";
}
return "";
}


string getAccessoryWithFName(string FName) {
if (isContain(FName, "BP_QK_Mid_Compensator_Pickup_C")) {
return "Nòng Giảm Giật";
}
if (isContain(FName, "BP_QK_Large_Compensator_Pickup_C")) {
return "Nòng Giảm Thanh";
}
if (isContain(FName, "BP_QT_UZI_Pickup_C")) {
return "UZIQT";
}
if (isContain(FName, "BP_QT_A_Pickup_C")) {
return "QT_A";
}

if (isContain(FName, "BP_WB_LightGrip_Pickup_C")) {
return "Tay Cầm Nhẹ";
}
return "";
}

string getBulletWithFName(string FName) {
if (isContain(FName, "BP_Ammo_762mm_Pickup_C")) {
return "[Đạn]762mm";
}
if (isContain(FName, "BP_Ammo_556mm_Pickup_C")) {
return "[Đạn]556mm";
}
if (isContain(FName, "BP_Ammo_9mm_Pickup_C")) {
return "[Đạn]9mm";
}
return "";
}

string getDrugWithFName(string FName) {
if (isContain(FName, "Injection_Pickup_C")) {
return "Injection";
}
if (isContain(FName, "Firstaid_Pickup_C")) {
return "Firstaid";
}

if (isContain(FName, "Drink_Pickup_C")) {
return "Drink";
}
return "";
}

string getBoxWithFName(string FName) {
if (isContain(FName, "PickUpListWrapperActor")) {
return "PickUpListWrapperActor";
}
return "";
}
string getBPcWithFName(string FName) {
if (isContain(FName, "BP_AirDropBox_C")) {
return "AirDropBox";
}
return "";
}

string getWrapperWithFName(string FName) {
if (isContain(FName, "BP_Pistol_Flaregun_Wrapper_C")) {
return "Flaregun";
}
return "";
}

string getEarlyWarningWithFName(string FName) {
if (isContain(FName, "ProjGrenade_BP_C")) {
return "Grenade！";//BP_AirDropBox_C
}
if (isContain(FName, "ProjFire_BP_C")) {
return "Fire！";
}
if (isContain(FName, "ProjBurn_BP_C")) {
return "Burn！";
}
return "";
}

Vector3 MatrixToVector(FMatrix matrix) {
return Vector3(matrix[3][0], matrix[3][1], matrix[3][2]);
}

FMatrix MatrixMulti(FMatrix m1, FMatrix m2) {
FMatrix matrix = FMatrix();
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
for (int k = 0; k < 4; k++) {
matrix[i][j] += m1[i][k] * m2[k][j];
}
}
}
return matrix;
}

FMatrix TransformToMatrix(FTransform transform) {
FMatrix matrix;

matrix[3][0] = transform.Translation.X;
matrix[3][1] = transform.Translation.Y;
matrix[3][2] = transform.Translation.Z;

float x2 = transform.Rotation.x + transform.Rotation.x;
float y2 = transform.Rotation.y + transform.Rotation.y;
float z2 = transform.Rotation.z + transform.Rotation.z;

float xx2 = transform.Rotation.x * x2;
float yy2 = transform.Rotation.y * y2;
float zz2 = transform.Rotation.z * z2;

matrix[0][0] = (1.0f - (yy2 + zz2)) * transform.Scale3D.X;
matrix[1][1] = (1.0f - (xx2 + zz2)) * transform.Scale3D.Y;
matrix[2][2] = (1.0f - (xx2 + yy2)) * transform.Scale3D.Z;

float yz2 = transform.Rotation.y * z2;
float wx2 = transform.Rotation.w * x2;
matrix[2][1] = (yz2 - wx2) * transform.Scale3D.Z;
matrix[1][2] = (yz2 + wx2) * transform.Scale3D.Y;

float xy2 = transform.Rotation.x * y2;
float wz2 = transform.Rotation.w * z2;
matrix[1][0] = (xy2 - wz2) * transform.Scale3D.Y;
matrix[0][1] = (xy2 + wz2) * transform.Scale3D.X;

float xz2 = transform.Rotation.x * z2;
float wy2 = transform.Rotation.w * y2;
matrix[2][0] = (xz2 + wy2) * transform.Scale3D.Z;
matrix[0][2] = (xz2 - wy2) * transform.Scale3D.X;

matrix[0][3] = 0;
matrix[1][3] = 0;
matrix[2][3] = 0;
matrix[3][3] = 1;

return matrix;
}

FMatrix RotatorToMatrix(FRotator rotation) {
float radPitch = rotation.Pitch * ((float) M_PI / 180.0f);
float radYaw = rotation.Yaw * ((float) M_PI / 180.0f);
float radRoll = rotation.Roll * ((float) M_PI / 180.0f);

float SP = sinf(radPitch);
float CP = cosf(radPitch);
float SY = sinf(radYaw);
float CY = cosf(radYaw);
float SR = sinf(radRoll);
float CR = cosf(radRoll);

FMatrix matrix;

matrix[0][0] = (CP * CY);
matrix[0][1] = (CP * SY);
matrix[0][2] = (SP);
matrix[0][3] = 0;

matrix[1][0] = (SR * SP * CY - CR * SY);
matrix[1][1] = (SR * SP * SY + CR * CY);
matrix[1][2] = (-SR * CP);
matrix[1][3] = 0;

matrix[2][0] = (-(CR * SP * CY + SR * SY));
matrix[2][1] = (CY * SR - CR * SP * SY);
matrix[2][2] = (CR * CP);
matrix[2][3] = 0;

matrix[3][0] = 0;
matrix[3][1] = 0;
matrix[3][2] = 0;
matrix[3][3] = 1;

return matrix;
}
Vector3 Add_Vectors(Vector3 A, Vector3 B){

return A + B;
}

Vector3 Multiply_VectorFloat(Vector3 A, float B){

//return A * B;
}


Vector3 CalcAngle(Vector3 LocalHeadPosition, Vector3 AimPosition) {

Vector3 vecDelta = Vector3((LocalHeadPosition.X - AimPosition.X), (LocalHeadPosition.Y - AimPosition.Y), (LocalHeadPosition.Z - AimPosition.Z));
float hyp = (float)sqrt(vecDelta.X * vecDelta.X + vecDelta.Y * vecDelta.Y);

Vector3 ViewAngles;
ViewAngles.Y = -(float)atan(vecDelta.Z / hyp) * (float)(180 / M_PI);
ViewAngles.X = (float)atan(vecDelta.Y / vecDelta.X) * (float)(180 / M_PI);

if (vecDelta.X >= 0)
ViewAngles.X += 180.0f;


return ViewAngles;
}


Vector3 ClampAngles(Vector3 angles) {


while (angles.X < -180.0f)
angles.X += 360.0f;
while (angles.X > 180.0f)
angles.X -= 360.0f;

if (angles.Y < -74)
angles.Y = -74;
if (angles.Y > 74)
angles.Y = 74;

return angles;
}

Vector2 WorldToScreen(Vector3 worldLocation, MinimalViewInfo camViewInfo, int width, int height) {
FMatrix tempMatrix = RotatorToMatrix(camViewInfo.Rotation);

Vector3 vAxisX(tempMatrix[0][0], tempMatrix[0][1], tempMatrix[0][2]);
Vector3 vAxisY(tempMatrix[1][0], tempMatrix[1][1], tempMatrix[1][2]);
Vector3 vAxisZ(tempMatrix[2][0], tempMatrix[2][1], tempMatrix[2][2]);

Vector3 vDelta = worldLocation - camViewInfo.Location;

Vector3 vTransformed(Vector3::Dot(vDelta, vAxisY), Vector3::Dot(vDelta, vAxisZ), Vector3::Dot(vDelta, vAxisX));

if (vTransformed.Z < 1.0f) {
vTransformed.Z = 1.0f;
}

float fov = camViewInfo.FOV;
float screenCenterX = (width / 2.0f);
float screenCenterY = (height / 2.0f);

return Vector2(
(screenCenterX + vTransformed.X * (screenCenterX / tanf(fov * ((float) M_PI / 360.0f))) / vTransformed.Z),
(screenCenterY - vTransformed.Y * (screenCenterX / tanf(fov * ((float) M_PI / 360.0f))) / vTransformed.Z)
);
}
Vector3 Draw3DBox(Vector3 origin, Vector3 extends)
{
 
    // bottom plane
    Vector3 one = origin;
    Vector3 two = origin; two.X += extends.X;
    Vector3 three = origin; three.X += extends.X; three.Y += extends.Y;
    Vector3 four = origin; four.Y += extends.Y;
 
    Vector3 five = one; five.Z += extends.Z;
    Vector3 six = two; six.Z += extends.Z;
    Vector3 seven = three; seven.Z += extends.Z;
    Vector3 eight = four; eight.Z += extends.Z;
 
    Vector3 s1, s2, s3, s4, s5, s6, s7, s8;
    
 
   
}

static void didFinishLaunching(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef info)
{
    
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
[[IFuckYou getInstance] entry];
    
    
});
}

__attribute__((constructor)) static void initialize()
{
CFNotificationCenterAddObserver(CFNotificationCenterGetLocalCenter(), NULL, &didFinishLaunching, (CFStringRef)UIApplicationDidFinishLaunchingNotification, NULL, CFNotificationSuspensionBehaviorDrop);
}


@interface IFuckYou ()

@property (nonatomic, strong) NSTimer *dataTimer;
@property (nonatomic, strong) NSTimer *actionTimer;


@property (nonatomic, assign) bool isAimbot;
//@property (nonatomic, assign) bool isAimbotS;
//@property (nonatomic, assign) bool isAimbotF;
//@property (nonatomic, assign) bool isAimbotA;

//@property (nonatomic, assign) bool isBulletSpeed;//
//@property (nonatomic, assign) bool NoGravity;//
@property (nonatomic, assign) bool isAimbotscope;


@end


@implementation IFuckYou


- (instancetype)init
{
if (self = [super init]) {
self.playerList = [NSMutableArray array];
self.propsList = [NSMutableArray array];
self.playerPool = [[JFPlayerPool alloc] init];
self.propsPool = [[JFPropsPool alloc] init];

self.localPlayer = [self.playerPool getObjFromPool];
self.localPlayer.type = PlayerTypeMyself;
}
return self;
}

static IFuckYou *instance = nil;

+ (IFuckYou *)getInstance
{
static dispatch_once_t onceToken;
dispatch_once(&onceToken, ^{
instance = [[self alloc] init];
});

return instance;
}

+ (id)allocWithZone:(struct _NSZone*)zone
{
static dispatch_once_t onceToken;
dispatch_once(&onceToken, ^{
instance = [super allocWithZone:zone];
});
return instance;
}


- (BOOL)vmreadData:(void *)buf address:(long)address length:(long)length
{
vm_size_t size = 0;
kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)address, length, (vm_address_t)buf, &size);
if(error != KERN_SUCCESS || size != length){
return NO;
}
return YES;
}
//std::wstring read_unicode(const std::uintptr_t address, std::size_t size)
//{
//    const auto buffer = std::make_unique<wchar_t[]>(size);
//   _read((uintptr_t)address, buffer.get(), size * 2, 0);
//    return std::wstring(buffer.get());
//}
- (void)entry
{
module = (kaddr)_dyld_get_image_vmaddr_slide(0);
if (!self.floatingMenuView.superview) {
[[UIApplication sharedApplication].keyWindow addSubview:self.overlayView];
[[UIApplication sharedApplication].keyWindow addSubview:self.floatingMenuView];
}
[self startFuckYou];
}

- (void)startFuckYou
{
[self cancelTimer];
self.dataTimer = [NSTimer timerWithTimeInterval:1.0f/60 target:self selector:@selector(readData) userInfo:nil repeats:YES];
[[NSRunLoop currentRunLoop] addTimer:self.dataTimer forMode:NSRunLoopCommonModes];

self.actionTimer = [NSTimer timerWithTimeInterval:1.0f/60 target:self selector:@selector(localPlayerAction) userInfo:nil repeats:YES];
[[NSRunLoop currentRunLoop] addTimer:self.actionTimer forMode:NSRunLoopCommonModes];
}
void VectorAnglesRadar(Vector3& forward, Vector3& angles)
{
    if (forward.X == 0.f && forward.Y == 0.f)
    {
        angles.X = forward.Z > 0.f ? -90.f : 90.f;
        angles.Y = 0.f;
    }
    else
    {
        angles.X = RAD2DEG(atan2(-forward.Z, forward.X));
        angles.Y = RAD2DEG(atan2(forward.Y, forward.X));
    }
    angles.Z = 0.f;
}

Vector3 WorldToRadar(float Yaw, Vector3 Origin, Vector3 LocalOrigin, float PosX, float PosY, Vector3 Size, bool& outbuff)
{
    bool flag = false;
    double num = (double)Yaw;
    double num2 = num * 0.017453292519943295;
    float num3 = (float)cosl(num2);
    float num4 = (float)sinf(num2);
    float num5 = Origin.X - LocalOrigin.X;
    float num6 = Origin.Y - LocalOrigin.Y;
    Vector3 vector;
    vector.X = (num6 * num3 - num5 * num4) / 150.f;
    vector.Y = (num5 * num3 + num6 * num4) / 150.f;
    Vector3 vector2;
    vector2.X = vector.X + PosX + Size.X / 2.f;
    vector2.Y = -vector.Y + PosY + Size.Y / 2.f;
    bool flag2 = vector2.X > PosX + Size.X;
    if (flag2)
    {
        vector2.X = PosX + Size.X;
    }
    else
    {
        bool flag3 = vector2.X < PosX;
        if (flag3)
        {
            vector2.X = PosX;
        }
    }
    bool flag4 = vector2.Y > PosY + Size.Y;
    if (flag4)
    {
        vector2.Y = PosY + Size.Y;
    }
    else
    {
        bool flag5 = vector2.Y < PosY;
        if (flag5)
        {
            vector2.Y = PosY;
        }
    }
    bool flag6 = vector2.Y == PosY || vector2.X == PosX;
    if (flag6)
    {
        flag = true;
    }
    outbuff = flag;
    return vector2;
}
FRotator Conv_VectorToRotator(Vector3 a){
 
    FRotator R;
 
    // Find yaw.
    R.Yaw = atan2(a.Y,a.X) * (180 /3.141592654f);
 
    // Find pitch.
    R.Pitch = atan2(a.Z,sqrt(a.X*a.X+a.Y*a.Y)) * (180 /3.141592654f);
 
    // Find roll.
    R.Roll = 0;
 
    return R;
}
- (void)cancelTimer
{
if (self.dataTimer) {
[self.dataTimer invalidate];
self.dataTimer = nil;
}
if (self.actionTimer) {
[self.actionTimer invalidate];
self.actionTimer = nil;
}
[self recyclePlayer];
}

- (void)recyclePlayer
{
for (JFPlayer *player in self.playerList) {
[self.playerPool putObj2Pool:player];
}
[self.playerList removeAllObjects];

for (JFProps *props in self.propsList) {
[self.propsPool putObj2Pool:props];
}
[self.propsList removeAllObjects];
}

- (void)readData
{
if (!self.overlayView.isStartTimer) {
return;
}
[self recyclePlayer];

if (![self readLocalPlayerInfo]) return;

auto GWorld = uworld();
auto ULevel = GetPtr(GWorld + 0x30);
auto ActorArray = GetPtr(ULevel + 0xA0);
auto ActorCount = Read<int>(ULevel + 0xA8);

for (int i = 0; i < ActorCount; i++) {
kaddr base = GetPtr(ActorArray + i * 8);
if (!IsValidAddress(base) || base == self.localPlayer.base) continue;

string FName = GetFName(base);
if (FName.empty()) continue;

if (isPlayer(FName)) {
JFPlayer *player = [self.playerPool getObjFromPool];
player.base = base;

if ([self readPlayerInfo:player]) {
if (self.localPlayer.teamNo == player.teamNo) {
player.type = PlayerTypeTeam;
} else {
player.type = PlayerTypeEnemy;
}
[self.playerList addObject:player];
} else {
[self.playerPool putObj2Pool:player];
}
} else {
if (!self.overlayView.isShowProps) continue;

string name;
PropsType type = PropsTypeNone;

if (self.overlayView.isShowPropsEarlyWarning && !((name = getEarlyWarningWithFName(FName)).empty())) {
type = PropsTypeEarlyWarning;
} else if (self.overlayView.isShowPropsVehicle && !((name = getVehicleWithFName(FName)).empty())) {
type = PropsTypeVehicle;
} else if (self.overlayView.isShowPropsWeapon && !((name = getWeaponWithFName(FName)).empty())) {
type = PropsTypeWeapon;
} else if (self.overlayView.isShowPropsArmor && !((name = getArmorWithFName(FName)).empty())) {
type = PropsTypeArmor;
} else if (self.overlayView.isShowPropsSight && !((name = getSightWithFName(FName)).empty())) {
type = PropsTypeSight;
} else if (self.overlayView.isShowPropsAccessory && !((name = getAccessoryWithFName(FName)).empty())) {
type = PropsTypeAccessory;
} else if (self.overlayView.isShowPropsBullet && !((name = getBulletWithFName(FName)).empty())) {
type = PropsTypeBullet;
} else if (self.overlayView.isShowPropsDrug && !((name = getDrugWithFName(FName)).empty())) {
type = PropsTypeDrug;

} else if (self.overlayView.BoxWith && !((name = getBoxWithFName(FName)).empty())) {
type = PickUpListWrapperActor;

} else if (self.overlayView.BPc && !((name = getBPcWithFName(FName)).empty())) {
type = AirDropBox;

} else if (self.overlayView.Pistol && !((name = getWrapperWithFName(FName)).empty())) {
type = Flaregun;//信号

 }


/* if (name.empty() || type == PropsTypeNone) {
continue;
} */

JFProps *props = [self.propsPool getObjFromPool];
props.base = base;
props.name = name;
props.type = type;

auto rootComponent = GetPtr(props.base + ??????);//done
if (/* IsValidAddress(rootComponent) */true) {
props.worldPos = Read<Vector3>(rootComponent + ???????);//done
props.distance = Vector3::Distance(props.worldPos, POV.Location) / 100.0f;
if (props.distance > self.overlayView.propsDistance) {
[self.propsPool putObj2Pool:props];
continue;
}

props.screenPos = WorldToScreen(props.worldPos, POV, SCREEN_WIDTH, SCREEN_HEIGHT);

[self.propsList addObject:props];
} else {
[self.propsPool putObj2Pool:props];
}
}
}
}
-(void)trackingcar{
    
}

- (bool)readLocalPlayerInfo
{

auto GWorld = uworld();
auto NetDriver = GetPtr(GWorld + 0x38);
auto ServerConnection = GetPtr(NetDriver + 0x78);
localPlayerController = GetPtr(ServerConnection + 0x30);
self.localPlayer.base = GetPtr(localPlayerController + ???????);//done

if (IsValidAddress(self.localPlayer.base)) {
string FName = GetFName(self.localPlayer.base);
if (FName.empty()) return false;

if (isPlayer(FName)) {
if ([self readPlayerInfo:self.localPlayer]) {

                 self.isFire = Read<bool>(self.localPlayer.base + 0x14e8);//done
                 self.Gunads = Read<bool>(self.localPlayer.base + 0xf59);//done

               auto weaponManagerComponent = GetPtr(self.localPlayer.base + 0x1e98);
                     
                 auto shootWeaponComponent = GetPtr(weaponManagerComponent + 0xd68);
//               Vtabel = Read<uintptr_t>(shootWeaponComponent + 0x0);
    ownerShootWeapon = GetPtr(shootWeaponComponent + 0x208);//done

//                 ownerShootWeapon = GetPtr(shootWeaponComponent + 0x208);//done

 }
               } else {
               ownerShootWeapon = 0;
               }
               } else {
               self.localPlayer.base = 0;
               }

auto playerCameraManager = GetPtr(localPlayerController + 0x470);//done
POV = Read<MinimalViewInfo>(playerCameraManager + 0xff0 +0x10);//done
controlRotation = localPlayerController + 0x408;//done

return IsValidAddress(localPlayerController) && IsValidAddress(playerCameraManager);
}

- (bool)readPlayerInfo:(JFPlayer *)player
{
auto rootComponent = GetPtr(player.base + 0x1b8);//done 0x1b8
if ( IsValidAddress(rootComponent)) {
player.worldPos = Read<Vector3>(rootComponent + 0x160);//done 0x160

player.distance = Vector3::Distance(player.worldPos, POV.Location) / 100.0f;
if (player.distance > self.overlayView.espDistance) return false;
} else {
return false;
}
   
            
    
player.hp = Read<float>(player.base + 0xcc8);//done
player.maxHp = Read<float>(player.base + 0xccc);//done

player.signalHP = Read<float>(player.base + 0xcd0);
player.signalHPMax = Read<float>(player.base + 0xcdc);
player.isFallDown = player.hp == 0;

player.isDead = Read<bool>(player.base + 0x888);//done
if ( player.hp < 0 || player.hp > 100 ||
player.maxHp != 100 ||
player.hp > player.maxHp ||
player.signalHP < 0 || player.signalHPMax > 100 ||
player.signalHPMax != 100 ||
player.signalHP > player.signalHPMax ||
player.isDead) return false;
auto nameAddr = GetPtr(player.base + 0x888);//    struct FString PlayerName
if (IsValidAddress(nameAddr)) {
UTF8 name[32] = "";
UTF16 buf16[16] = {0};
_read(nameAddr, buf16, 28);
Utf16_To_Utf8(buf16, name, 28, strictConversion);

player.name = string((const char *)name);
}
auto flagAdd = GetPtr(player.base + 0x94c);//    int DyeDebugFlag
if (IsValidAddress(flagAdd)) {
UTF8 flag[32] = "";
UTF16 buf116[16] = {0};
_read(flagAdd, buf116, 28);
Utf16_To_Utf8(buf116, flag, 28, strictConversion);

player.flag = string((const char *)flag);
}

player.playerKey = Read<UInt32>(player.base + 0x870);//done


player.isAI = Read<bool>(player.base + 0x960);//done

player.teamNo = Read<int>(player.base + 0x8d0);//done

Vector2 topScreenPos = WorldToScreen(Vector3(player.worldPos.X, player.worldPos.Y, player.worldPos.Z + 100), POV, SCREEN_WIDTH, SCREEN_HEIGHT);
Vector2 bottomScreenPos = WorldToScreen(Vector3(player.worldPos.X, player.worldPos.Y, player.worldPos.Z - 100), POV, SCREEN_WIDTH, SCREEN_HEIGHT);

float height = max<float>(bottomScreenPos.Y - topScreenPos.Y, 5.0f);
float width = height * 0.5f;
float x = topScreenPos.X - width * 0.5f;
float y = topScreenPos.Y;
player.box = CGRectMake(x, y, width, height);
;
if (self.overlayView.isBoneEsp) {
[self readBoneData:player];
}

player.isVisible = [self lineOfSightToViewPoint:Vector3(player.worldPos.X, player.worldPos.Y, player.worldPos.Z + 100)];
return true;
}

- (bool)lineOfSightToViewPoint:(Vector3)viewPoint
{
if (!IsValidAddress(self.localPlayer.base) || !IsValidAddress(localPlayerController)) {
return false;
}
return reinterpret_cast<bool(__fastcall *)(kaddr, kaddr, Vector3*, bool)>(GetRealOffset(Offsets::LineOfSightTo_Func))(localPlayerController, self.localPlayer.base, &viewPoint, false);
}

- (Vector3)getBoneWorldPos:(kaddr)base index:(int)index
{
auto mesh = GetPtr(base + 0x438);
if (IsValidAddress(mesh)) {
    
FTransform meshTrans = Read<FTransform>(mesh + 0x1a0);
FMatrix c2wMatrix = TransformToMatrix(meshTrans);
auto boneArray = GetPtr(mesh + 0x738);
if (IsValidAddress(boneArray)) {
FTransform boneTrans = Read<FTransform>(boneArray + index * 48);
FMatrix boneMatrix = TransformToMatrix(boneTrans);
return MatrixToVector(MatrixMulti(boneMatrix, c2wMatrix));
}
}
return Vector3();
}

- (Vector2)getBoneScreenPos:(kaddr)boneTransAddr c2wMatrix:(FMatrix)c2wMatrix
{
FTransform boneTrans = Read<FTransform>(boneTransAddr);
FMatrix boneMatrix = TransformToMatrix(boneTrans);
Vector3 relLocation = MatrixToVector(MatrixMulti(boneMatrix, c2wMatrix));
return WorldToScreen(relLocation, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
}

- (Vector3)getBoneWorldPos:(kaddr)boneTransAddr c2wMatrix:(FMatrix)c2wMatrix
{
FTransform boneTrans = Read<FTransform>(boneTransAddr);
FMatrix boneMatrix = TransformToMatrix(boneTrans);
return MatrixToVector(MatrixMulti(boneMatrix, c2wMatrix));
}

- (void)readBoneData:(JFPlayer *)player
{
auto mesh = GetPtr(player.base + 0x438);
    
    auto mymesh = GetPtr(self.localPlayer.base + 0x438);

if (IsValidAddress(mesh)) {
    player.lastRender = Read<float>(mymesh +0x378);
//    player.BoxSphereBounds= Read<Vector3>(mesh +0x844 +0xc);
    player.ActorRender = Read<float>(mesh +0x378);
FTransform meshTrans = Read<FTransform>(mesh + 0x1a0);
 FMatrix c2wMatrix = TransformToMatrix(meshTrans);
 auto boneArray  = GetPtr(mesh + 0x738);
if (IsValidAddress(boneArray)) {
BoneData boneData;
BoneVisibleData boneVisibleData;

   Vector3  head = [self getBoneWorldPos:boneArray + 6 * 48 c2wMatrix:c2wMatrix];
boneData.head = WorldToScreen(head, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.head = [self lineOfSightToViewPoint:head];

Vector3 chest = [self getBoneWorldPos:boneArray + 4 * 48 c2wMatrix:c2wMatrix];
boneData.chest = WorldToScreen(chest, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.chest = [self lineOfSightToViewPoint:chest];

Vector3 pelvis = [self getBoneWorldPos:boneArray + 1 * 48 c2wMatrix:c2wMatrix];
boneData.pelvis = WorldToScreen(pelvis, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.pelvis = [self lineOfSightToViewPoint:pelvis];

Vector3 leftShoulder = [self getBoneWorldPos:boneArray + 12 * 48 c2wMatrix:c2wMatrix];
boneData.leftShoulder = WorldToScreen(leftShoulder, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.leftShoulder = [self lineOfSightToViewPoint:leftShoulder];

Vector3 rightShoulder = [self getBoneWorldPos:boneArray + 33 * 48 c2wMatrix:c2wMatrix];
boneData.rightShoulder = WorldToScreen(rightShoulder, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.rightShoulder = [self lineOfSightToViewPoint:rightShoulder];

Vector3 leftElbow = [self getBoneWorldPos:boneArray + 13 * 48 c2wMatrix:c2wMatrix];
boneData.leftElbow = WorldToScreen(leftElbow, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.leftElbow = [self lineOfSightToViewPoint:leftElbow];

Vector3 rightElbow = [self getBoneWorldPos:boneArray + 34 * 48 c2wMatrix:c2wMatrix];
boneData.rightElbow = WorldToScreen(rightElbow, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.rightElbow = [self lineOfSightToViewPoint:rightElbow];

Vector3 leftHand = [self getBoneWorldPos:boneArray + 14 * 48 c2wMatrix:c2wMatrix];
boneData.leftHand = WorldToScreen(leftHand, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.leftHand = [self lineOfSightToViewPoint:leftHand];

Vector3 rightHand = [self getBoneWorldPos:boneArray + 35 * 48 c2wMatrix:c2wMatrix];
boneData.rightHand = WorldToScreen(rightHand, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.rightHand = [self lineOfSightToViewPoint:rightHand];

Vector3 leftThigh = [self getBoneWorldPos:boneArray + 53 * 48 c2wMatrix:c2wMatrix];
boneData.leftThigh = WorldToScreen(leftThigh, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.leftThigh = [self lineOfSightToViewPoint:leftThigh];

Vector3 rightThigh = [self getBoneWorldPos:boneArray + 57 * 48 c2wMatrix:c2wMatrix];
boneData.rightThigh = WorldToScreen(rightThigh, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.rightThigh = [self lineOfSightToViewPoint:rightThigh];

Vector3 leftKnee = [self getBoneWorldPos:boneArray + 54 * 48 c2wMatrix:c2wMatrix];
boneData.leftKnee = WorldToScreen(leftKnee, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.leftKnee = [self lineOfSightToViewPoint:leftKnee];

Vector3 rightKnee = [self getBoneWorldPos:boneArray + 58 * 48 c2wMatrix:c2wMatrix];
boneData.rightKnee = WorldToScreen(rightKnee, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.rightKnee = [self lineOfSightToViewPoint:rightKnee];

Vector3 leftFoot = [self getBoneWorldPos:boneArray + 55 * 48 c2wMatrix:c2wMatrix];
boneData.leftFoot = WorldToScreen(leftFoot, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.leftFoot = [self lineOfSightToViewPoint:leftFoot];

Vector3 rightFoot = [self getBoneWorldPos:boneArray + 59 * 48 c2wMatrix:c2wMatrix];
boneData.rightFoot = WorldToScreen(rightFoot, POV, SCREEN_WIDTH, SCREEN_HEIGHT);
boneVisibleData.rightFoot = [self lineOfSightToViewPoint:rightFoot];

player.boneData = boneData;
player.boneVisibleData = boneVisibleData;
}
}
}



- (void)localPlayerAction
{
if (!self.overlayView.isStartTimer || self.localPlayer == nil) return;

[self modifyWeaponData];
[self aimbot];
}

- (void)modifyWeaponData
{




    long emeCurrentWeapon = GetPtr(self.localPlayer.base + 0x3a70);
    if (emeCurrentWeapon > 0x100000000 && emeCurrentWeapon < 0x200000000){
    kaddr shootWeaponEntityComp = GetPtr(emeCurrentWeapon + 0xea8);
        
        isScoopOpen = Read<bool>(shootWeaponEntityComp + 0xb36);

    if (self.overlayView.isNorecoil && self.isFire&& self.Gunads) {
    if (IsValidAddress(shootWeaponEntityComp)) {

        float AccessoriesVRecoilFactor =Read<float>(shootWeaponEntityComp +0xa18);
          float AccessoriesHRecoilFactor =Read<float>(shootWeaponEntityComp + 0xa1c);
    float srecoil =Read<float>(shootWeaponEntityComp + 0xa1c);

    if (AccessoriesVRecoilFactor != 0 && AccessoriesHRecoilFactor != 0 )
    {
    Write<float>(shootWeaponEntityComp + 0xa18, 0.001);
    Write<float>(shootWeaponEntityComp + 0xa1c, 0.001);
    Write<float>(shootWeaponEntityComp + 0xb28, 0.001);

    }

    }
    }
    if (self.overlayView.NoSpread && self.isFire&& self.Gunads) {
    if (IsValidAddress(shootWeaponEntityComp)) {
    float GameDeviationFactor =Read<float>(shootWeaponEntityComp + 0xa74);
    float ShotGunHorizontalSpread =Read<float>(shootWeaponEntityComp + 0xa70);
    float ShotGunVerticalSpread =Read<float>(shootWeaponEntityComp + 0xa6c);

    if (GameDeviationFactor != 0 && ShotGunHorizontalSpread != 0 && ShotGunVerticalSpread != 0)
    {
    Write<float>(shootWeaponEntityComp + 0xa74, 0.001);
    Write<float>(shootWeaponEntityComp + 0xa70, 0.001);
    Write<float>(shootWeaponEntityComp + 0xa6c, 0.001);
    }

    }
    }
        if (self.overlayView.isBulletSpeed && self.isFire) {
            if (IsValidAddress(shootWeaponEntityComp)) {
               Write<float>(shootWeaponEntityComp + 0x4d0, 0.99999999);

            }
        }

        if (self.overlayView.NoGravity && self.isFire&& self.Gunads) {
         if (IsValidAddress(shootWeaponEntityComp)) {
        float Gravity = Read<float>(shootWeaponEntityComp + 0x2dc);//0x420
                                if (Gravity != 0)
                                {
                                    Write<float>(shootWeaponEntityComp + 0x2dc, 0.001);

                                }

         }
         }

    }
    }
    void (*orig_shoot_event)(void *thiz , Vector3 start, FRotator rotation, void *unk1, int unk2) = 0;
     
    void shoot_event(void *thiz, Vector3 start, FRotator rotation, void *weapon, int unk1) {
     rotation = Rotation;
     return orig_shoot_event(thiz, start, rotation, weapon, unk1);
    }

- (void)aimbot
{
if (!(self.overlayView.isAimbot || self.overlayView.isBulletTrack)) return;

[self filterBestAimPlayer];
  /*
    if(isScoopOpen) {

        self.isFire = true;

    }*/
    
    
    /*
    for (JFPlayer *player in self.playerList) {
        if (player.isVisible ){
            self.isFire = true;
            
        }
    }
    */
    
    
    
    
    
    /*
     
     if(self.overlayView.nolockb) {
         //không lock bot
     }else{
         //có lock bot
         if (!(player.isAI)) {
             // nếu không phải bot
             self.isFire = true;
         }else{
             // nếu là bot
         }
     }
     
     
     */
     
    
    if(self.overlayView.aimlockp) {
        for (JFPlayer *player in self.playerList) {
                if(self.overlayView.nolockb) {
                //không lock bot
                if (player.isVisible && !(player.isAI)){
                    //nếu nhìn được và không phải bot
                    self.isFire = true;
                }
                }else{
                //nếu nhìn được và phải là bot
                if (player.isVisible){
                self.isFire = true;
                }
            }
        }
    }
    

    
    
    
    
if (self.isFire) {
if (IsValidAddress(self.lockActor)) {
float targetHp = Read<float>(self.lockActor + 0xcc8);
float localPlayerHp = Read<float>(self.localPlayer.base + 0xcc8);
if (targetHp > 0 && localPlayerHp > 0) {
if (self.overlayView.isBulletTrack) {
    
    
    Vector3 lockBoneV3 = [self getBoneWorldPos:self.lockActor index:self.overlayView.aimbotPart];
    Vector3 diffV3 = lockBoneV3 - POV.Location;
    auto playerCameraManager = GetPtr(localPlayerController + 0x470);
    float pitch = atan2f(diffV3.Z, sqrt(pow(diffV3.X, 2) + pow(diffV3.Y, 2))) * 57.29577951308f;
    float yaw = atan2f(diffV3.Y, diffV3.X) * 57.29577951308f;
        Write<float>(playerCameraManager + 0x488, pitch);
        Write<float>(playerCameraManager + 0x48c, yaw);
    
    
}
if (self.overlayView.isAimbot) {
    
    
    
    
    
    
Vector3 lockBoneV3 = [self getBoneWorldPos:self.lockActor index:self.overlayView.aimbotPart];
Vector3 diffV3 = lockBoneV3 - POV.Location;
float pitch = atan2f(diffV3.Z, sqrt(diffV3.X * diffV3.X + diffV3.Y * diffV3.Y)) * 57.29577951308f;
float yaw = atan2f(diffV3.Y, diffV3.X) * 57.29577951308f;
if (IsValidAddress(controlRotation)) {
if (Read<float>(controlRotation) != 0) {
Write<float>(controlRotation, pitch);
}
if (Read<float>(controlRotation + 0x4) != 0) {
Write<float>(controlRotation + 0x4, yaw);
}
}
    
    
    
}
} else {
self.lockActor = 0;
self.isFire = false;
}
}
} else {
self.lockActor = 0;
self.isFire = false;
}
}






- (void)filterBestAimPlayer
{
if (IsValidAddress(self.lockActor)) {
for (JFPlayer *player in self.playerList) {
if (self.lockActor == player.base) {
player.isBestAimTarget = true;
}
}
return;
}

JFPlayer *bestAimPlayer = nil;
float minCrossCenter = 100000;

for (JFPlayer *player in self.playerList) {
player.isBestAimTarget = false;
    if (player.isVisible &&
    player.type == PlayerTypeEnemy &&
        player.hp > 0 &&
    !(self.overlayView.isNearDeathNotAim && player.hp == 0)) {
float crossCenter = Vector2::Distance(Vector2(SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.5), Vector2(CGRectGetMidX(player.box), CGRectGetMidY(player.box)));
if (crossCenter < self.overlayView.aimbotRadius && crossCenter < minCrossCenter) {
minCrossCenter = crossCenter;
bestAimPlayer = player;
}
}
}

    
    
    
    
    
if (bestAimPlayer) {
bestAimPlayer.isBestAimTarget = true;
self.lockActor = bestAimPlayer.base;
bestAimPlayer = nil;
}
}


- (JFFloatingMenuView *)floatingMenuView
{
if (!_floatingMenuView) {
_floatingMenuView = [[JFFloatingMenuView alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
}
return _floatingMenuView;
}

- (JFOverlayView *)overlayView
{
if (!_overlayView) {
_overlayView = [[JFOverlayView alloc] initWithFrame:[UIScreen mainScreen].bounds];
}
return _overlayView;
}

@end
