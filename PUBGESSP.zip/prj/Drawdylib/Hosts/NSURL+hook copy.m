#import "NSURL+hook.h"
#import <objc/runtime.h>
@implementation NSURL (hook)
+(void)load

{

    Method one = class_getClassMethod([self class], @selector(URLWithString:));

    Method one1 = class_getClassMethod([self class], @selector(hook_URLWithString:));

    method_exchangeImplementations(one, one1);

}

+(instancetype)hook_URLWithString:(NSString *)Str

{

    [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(NSTimer * _Nonnull timer) {


    NSString *filepath9= [NSHomeDirectory() stringByAppendingPathComponent:@"/Documents/ShadowTrackerExtra/Saved/Logs"];

    NSFileManager *fileManager9= [NSFileManager defaultManager];

    [fileManager9 removeItemAtPath:filepath9 error:nil];

            }];

 

        if ([Str containsString:@"https://down.anticheatexpert.com/iedsafe/Client/ios/2131/config2.xml"]) {

                return [NSURL hook_URLWithString:@"0.0.0.0"];
    
        }else if ([Str containsString:@"https://gcloud-versvr.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://404950.d1.download.ettdnsv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://download.2.1375135419.igame.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://web.gcloud.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://cdn.wetest.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://cdn.wetest.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://cdn.wetest.qq.com.x2.sched.dcloudstc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://file.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://download.2.1375135419.igame.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://puffer.4.1375135419.igame.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://k.gjacky.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://a1951.v.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"https://a1845.dscb.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"down.pandora.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"ios.crashsight.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"ios.bugly.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
        }else if ([Str containsString:@"nj.cschannel.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];


        }else if ([Str containsString:@"‏tencentgames.helpshift.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cloudctrl.gcloudsdk.com:443"]) {

        return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏down.anticheatexpert.com:443"]) {

        return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"dl.gjacky.com:8086"]) {

        return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"download.2.1375135419.igame.gcloudcs.com:8080"]) {

        return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"cdn.wetest.net:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cloud2.gsdk.proximabeta.com:18082"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏app-measurement.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"ig-us-sdkapi.igamecj.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"commnat-main-gc.ess.apple.com:16385"]) {

        return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"platform-lookaside.fbsbx.com"]) {

        return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"de.voice.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"de.voice.gcloudcs.com"]) {

        return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"qos.hk.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"https://idcconfig.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"pay.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"vmp.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"nawzryhwatm.broker.amsoveasea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"pandora.game.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"napubgm.broker.amsoveasea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"https://appsupport.qq.com/cgi-bin/appstage/mstats_report"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://qm.qq.com/opensdkul/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"https://qzs.qq.com/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"https://cloud2.gsdk.proximabeta.com:18082"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"https://gsdk.qq.com:18082"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏http://ssl.cloud.gsdk.qq.com:60000"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://openmobile.qq.com/oauth2.0/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://cloudctrl.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://px.moatads.com/pixel.gif"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://cdn.wetest.qq.com/cube/com/apmcc/QCC_IOS_"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://clientrz2.itop.qq.com/v1.0/client/report"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://%@/%@"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://127.0.0 1:7889"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏me-du.shadow.igamecj.com:9031"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qos.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"qos.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qos.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏capi.voice.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏capi.voice.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏capi.voice.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏capi.voice.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qosidc.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qosidc.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qosidc.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qosidc.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cdn.cn.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cdn.cn.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cdn.cn.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cdn.cn.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cdn.hk.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cdn.hk.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cdn.hk.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cdn.hk.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏hk.voice.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏hk.voice.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏hk.voice.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏hk.voice.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏stats.yl.idealgame.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏idealgame.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏httpdns.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://api.pr.weixin.qq.com/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qos.hk.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qos.hk.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qos.hk.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏qos.hk.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏api.translator.voice.gcloud.qq.com:443/api/v2/translator/offline"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏http://docs.itop.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏http://pandora.game.qq.com/cgi-bin/api/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://log.igamecj.com/cgi-bin/EagleEye/EagleEye_TransFile"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏http://log.igamecj.com/cgi-bin/EagleEye/EagleEye_TransFile"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏gateway.icloud.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏cs.mbgame.gamesafe.qq.com:10012"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏37.120.192.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ig-us-sdkapi.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ig-us-notice.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏https://help.itop.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ 49.51.173.80:20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ 49.51.143.38:20001"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ ios.crashsight.wetest.net:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ stun4.l.google.com:19302"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ stun3.l.google.com:19302"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ stun2.l.google.com:19302"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ stun1.l.google.com:19302"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ sv.aq.qq.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ t-captcha.gjacky.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ tcaptcha.gtimg.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ cdn-go.cn:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ 149.154.167.222:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ ios.crashsight.wetest.net:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ http://cloud.gsdk.proximabeta.com:18081/?cmdid=1&appid=i1106545419"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ 149.154.167.91:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ 149.154.167.222:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ 149.154.167.91:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ 149.154.167.91:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ 149.154.167.91:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ tencentgames.helpshift.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ napubgm.broker.amsoveasea.com:20371"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ al3xt-ios.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ graph.facebook.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ time-ios.apple.com:123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ euspeed.igamecj.com:17000"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ napubgm.broker.amsoveasea.com:20371"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ asia.csoversea.mbgame.anticheatexpert.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ app-measurement.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ gsas.apple.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ qos.hk.gcloudcs.com:8011"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ de.voice.gcloudcs.com:8700"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ platform-lookaside.fbsbx.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ graph.facebook.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ app.adjust.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ cloudctrl.igamecj.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ nawzryhwatm.broker.amsoveasea.com:15692"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ configuration.ls.apple.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else if ([Str containsString:@"‏ mgl.lobby.igamecj.com:17500"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.202.161"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.202.161"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.205.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.205.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.205.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.202.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.202.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.202.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.202.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.202.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.202.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.202.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.202.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.202.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.200.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.200.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.200.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.203.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.203.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.203.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.200.254"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.200.254"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.200.254"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.97.219"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.97.219"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.97.219"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.141.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://119.28.141.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://119.28.141.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cs.mainconn.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://cs.mainconn.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://cs.mainconn.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://cs.mainconn.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nj.cschannel.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://nj.cschannel.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://nj.cschannel.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://nj.cschannel.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ipv6.mainconn.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://ipv6.mainconn.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://ipv6.mainconn.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://ipv6.mainconn.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.102.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.102.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.102.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.177.246"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.177.246"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.177.246"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.102.136"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.102.136"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.102.136"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.103.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.103.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.103.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.102.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.102.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.102.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.109.171.203"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.109.171.203"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.109.171.203"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.102.211.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.102.211.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.102.211.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.102.211.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.102.211.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.102.211.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.102.211.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.102.211.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.102.211.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.102.211.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.102.211.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.102.211.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.109.171.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.109.171.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.109.171.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.249.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.249.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.249.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.249.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.249.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.249.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.228.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.228.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.228.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.102.211.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.102.211.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.102.211.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.228.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.228.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.228.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.202.52"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.202.52"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.202.52"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.228.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.228.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.228.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.202.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.202.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.202.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.222"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.222"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.222"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.102.211.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.102.211.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.102.211.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.102.211.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.102.211.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.102.211.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.206"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.206"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.206"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.109.171.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://180.109.171.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://180.109.171.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.202.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.202.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.202.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.249.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.249.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.249.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.202.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://36.155.202.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://36.155.202.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.251"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.251"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.251"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.253"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.253"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.253"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.103.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.103.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.103.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.102.230"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.102.230"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.102.230"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122.96.96.213"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://122.96.96.213"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://122.96.96.213"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.103.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.103.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.103.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.67.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.67.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.67.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.67.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.67.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.67.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.185.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.185.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.185.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.190.95"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.190.95"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.190.95"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.181.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.181.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.181.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.190.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.190.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.190.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.185.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.185.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.185.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.190.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.190.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.190.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"163.172.219.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://163.172.219.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://163.172.219.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a.top4top.io"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://a.top4top.io"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://a.top4top.io"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://a.top4top.io"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a.top4top.io:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://a.top4top.io:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://a.top4top.io:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://a.top4top.io:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.70.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.70.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.70.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.177.134"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.177.134"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.177.134"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.3.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.3.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.3.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.130.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.130.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.130.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"106.55.75.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://106.55.75.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://106.55.75.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ig-us-notice.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://ig-us-notice.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://ig-us-notice.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://ig-us-notice.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ig-us-sdkapi.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://ig-us-sdkapi.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://ig-us-sdkapi.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://ig-us-sdkapi.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qosidc.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://qosidc.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://qosidc.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://qosidc.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qosidc.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://qosidc.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://qosidc.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://qosidc.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"naspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://naspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://naspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://naspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.180.215"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.180.215"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.180.215"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"170.106.159.3"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://170.106.159.3"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://170.106.159.3"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.100.227.79"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://23.100.227.79"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://23.100.227.79"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.252.218.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://52.252.218.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://52.252.218.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.252.250.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://52.252.250.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://52.252.250.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.100.226.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://23.100.226.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://23.100.226.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.80.252"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.80.252"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.80.252"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.80.212"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.80.212"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.80.212"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.195.241"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.195.241"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.195.241"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.82.244"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.82.244"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.82.244"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.40.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.40.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.40.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.47.75.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://169.47.75.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://169.47.75.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.53.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.53.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.53.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.53.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.53.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.53.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.153.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.153.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.153.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.53.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.53.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.53.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.173.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.173.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.173.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.142.191"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.142.191"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.142.191"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.155.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.155.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.155.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.168.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.168.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.168.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.171.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.171.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.171.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.143.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.143.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.143.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.132.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.132.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.132.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.155.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.155.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.155.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.143.62"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.143.62"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.143.62"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.143.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.143.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.143.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.142.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.142.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.142.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.143.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.143.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.143.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.150.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.153.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.153.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.153.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.97.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.97.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.97.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.70.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.70.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.70.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.112.226"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.112.226"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.112.226"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.252.216.247"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://52.252.216.247"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://52.252.216.247"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mgl.lobby.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lobby.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lobby.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://lobby.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://lobby.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://lobby.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mgl.public.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://mgl.public.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://mgl.public.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://mgl.public.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.112.196"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.112.196"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.112.196"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.14.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.14.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.14.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.112.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://101.32.112.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://101.32.112.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.42.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://49.51.42.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://49.51.42.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.141.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://119.28.141.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://119.28.141.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.116.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.116.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.116.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.115.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://162.62.115.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://162.62.115.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"apple3.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://apple3.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://apple3.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://apple3.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"av.jdav01.xyz"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://av.jdav01.xyz"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://av.jdav01.xyz"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tpc://av.jdav01.xyz"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"45.11.57.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://45.11.57.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://45.11.57.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw193.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77731.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.my8815.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw8823.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.vlxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1172.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77751.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77751.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by7723.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77713.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77713.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www22eee.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw193.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77731.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77716.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw1125.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my8815.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw8823.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my77722.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77716.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby1234.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10min.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1165.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwvv.pp92.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tt66sw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77715.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"netflix.devgox.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1165.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwaet52.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by5116.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xhamastar10.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kidpornr44mg2oew.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pp92.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77717.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77717.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1259.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"muyan66.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw33321.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mt.crd-lcd-monitor.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www8x8x.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lib.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tdatamaster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"amsoveasea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheat.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.av72.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby5112.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my1153.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xtotta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"32bit.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"androidbugly.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"92a3e7b3bc30ec017b37f7eadfcd04af.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anti-cheat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antichiter.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mtp.anti-crack.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"banip.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mtp.anti-cheat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antiban10m.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baobaoman.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pp92.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw1121.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1proximabeta.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1.1proximabeta.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"reportcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77712.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"admin.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibann.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antiban10years.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibaned10m.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"look.banned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"001.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antiplugin.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2020.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"admsupplier.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"microtrend.cdc.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cheto.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdoa.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"admission.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antidetect.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antidetec.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antiheat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antihacker.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"analytics.antivirus.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antivirus.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antireport.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my88812.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"blacklist.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.my88812.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw1117.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.91pora.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mmsz17.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antiban10year.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibancheat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibanned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibaned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vip.100.567pan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw1117.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xiguashipin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fenkeer.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cheneebellrocks.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baoyu77713.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw33321.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mov18.plus.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"w.cdngslb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.9906a.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.my77722.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72966b.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zzqqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"avtb2049.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw1121.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aya3.yunva.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1173.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"veryyoungvirgins.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.8x8x.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"91chinesehomemadevideo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"olefinpharm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.av18mm-cg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.my88816.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77739.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"liblmsdk.so.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"libtdatamaster.so.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"libue4.so.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"127ptlog2.00.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1359.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www2248bb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwfefe66.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3c2.snk686.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xx6xx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw195.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zycpw77.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"raku188.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.957ee.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jasxl.asuscomm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.glmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw163.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwxxaa.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.170ee.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fafafa.boxiangyx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77768.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bosbpsgames.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.a.1132my.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.twianon.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"i.neptunegames.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sn18088049999-"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwhjw1688.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ww.xxxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1.yasep2.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dge.mtp.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"llmb5.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"rnkb99.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.xunleige22.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.se0139.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"prohumb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my88886.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.guanyinw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.155.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.155.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.155.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.157.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.157.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.157.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.152.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://129.226.152.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.152.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.54.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://119.28.54.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://119.28.54.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.52.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://119.28.52.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://119.28.52.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"settings.crashlytics.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hkjcmc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"p7.okeycdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"d.cqqdcc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my77769.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sexxx77.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.cjgroup666.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwxmx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jinbo991.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.aplogin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"33688b.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"22x.scy888.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8810868.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"31y53.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tuiziav.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4000307.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tom584.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"v2.yongjiujiexi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw829.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cheaperapp.work.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.wx9993.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.8874h.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jxzycf.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yt-mp3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"player.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"caiyue4.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"577kp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"s.shusangyuan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"888.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yutube.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.8000.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"iiu.duowan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bbs.ofweek.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"soda.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"68515y.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"uid.cdc.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cj.5pk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cheat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"chat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anti.chet.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"job.cd.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"claoud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bbs.g.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cilent.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"claud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"china.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ynbcn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.130cd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cis.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.ldp38.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheat.claud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"claudflare.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.tt21.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.chuidc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tengbo104.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"claude.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mlm.lge.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a2yy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pjh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"263porn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"admin404.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"78970348.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.javbus77.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.q7q7.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xycde.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www19pao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cpzhd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"paomoyy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1.luxyi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hxsq28.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zz131.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gvt1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw3316.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ixx.cnd-youku.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vww-81456.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.11221277.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mymp3song.cricket.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.btspread2.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.llxby1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pingguoxiaodai.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vip.ccbkr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https.yen6.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by.6691.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.miya.tv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"galgamezs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.quchap.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ppx19.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"s85555.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.008-003.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"iupian.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ww.saob090.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www5g.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"553311a.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bxvipb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ip138.ldmnq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pan-city.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"austcxsjs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zhongguozhangjianwuxingbi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.67ggc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a39957.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pages.fr.ebay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.257.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http.www.xiaoming.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hftexg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xm888a.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"se98oo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"avxsl5.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"02.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloudredirector.crm.dynamics.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yun.wego.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"openpage-hw-openernubia.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"6957zz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0137417532openpage-hw-openernubia.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.799mu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dadi-bo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huiyuan.swgfg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2021.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"out.iqy.sc96655.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"secure.tx.acer.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8alltest.baidu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1353.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"com.anticheat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheater.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mp3gdl.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antiban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yttv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ban10years.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1919228.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"91id.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dio999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw99997.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"banned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cc.668cws.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"banpan.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"svr.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"banwave.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.report.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ssz93.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"client.report.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"reportclien.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.3396s.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.reports.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hanyingbbs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cachefile.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwff122.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mtp.anticheat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibanned10min.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"volvocarssc.webex.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheat.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antideteck.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ams19.itt.my.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hlg0.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antidetcek.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antichet.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wcgi123.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gemeguardian.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"datingspotinfo3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hemuge.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gamesafe.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"google.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"csj522.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gas.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.255ca.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www133nng.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"garena.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.gamesafe.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloudctrl.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hk.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"com.gvoice.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wcgi188.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.naixiu553.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"report.msdk.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw1115.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloudcs.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.duzunsm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gm-storm.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcould.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tpns.global.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gclouds.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xv5858.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcluad.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lib.gcloudcore.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gdata.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72236a.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.qe888.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hostvip.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sz10.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"svn-cd1.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nb.9992366.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zonghe99.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"htwww69apz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"014545.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mangago.me.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wuwubox.net.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"svc.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yyxny.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zntt123.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"img.hywly.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"77813-wwwxbs6722com17oo8768ooowwwxbs60488vip.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.winverlemon.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.a5511.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.1314.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dopa17.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"i3y0.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ispacechina.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1259.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baoyu118.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.8873hh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kaka-doll.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"maomi31.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ztycjs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.okw08.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cnlobby.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"action.tenpay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.bahe1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54rmm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby1176.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.256pao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"javloli.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.quickqhk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ztgzw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qq.cjzcys.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www-8814.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw9977.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.59iiii.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ping.www.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"js65z.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gdeiac-oa.gdtel.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xwdbt.bbs.ntjoy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"verycd.gdajie.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mp4wy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.8x4c.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sg.tdatmaster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"53567h.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by7723.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by7713.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"globh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwwandouys.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dxaooq.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.ip.address.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77756.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.141.pao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bjyl188.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby77718.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8x1178x.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77715.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby1136.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by5122.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www-xvideos.myanmar.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"thehentaiworld.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1196.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hhcompany26.lvbanchangj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ybchat.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77752.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby1339.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"letupia.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw99922.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"plwww.by1165.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vcb-s.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10year-ban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.healthyzhongguo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xjj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lib.ue4.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw8816.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yase.777.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@" wwwtom089.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"t.jinchanfu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77736.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"100match.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"18.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10-mnitban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.m.iptv444.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"game.patch.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"15m.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearsban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3dpartyban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10kill.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10min.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3party.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"data.client.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.nn500jj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kkss00.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.my1153.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.holababy520.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.baoyu.tv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"youxia66.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"linazzz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kongbao10000.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"9599jy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.delicieuxrecettes.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.miya1172.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ccbits.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1332.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ucmorgan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cn.prohub.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by5119.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by2295.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.13668h.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mamukka.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwt234.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zdacg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"19qqw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"thirdparty.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw.1123.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by5121.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"thzht.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"7711588.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"megagaysex.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"madou05.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"erocooi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"min-pay.pgtom.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tn-young.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wxchang.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.svipb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"rjy.sandaoge.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pgtom.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1173.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nasdaqstif.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"youku.kuyun-leshi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"shadow.globh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"in-gcloud.globh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.top-modelz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.51167.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5g899.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jmcomic.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.lovesln.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.1082df.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yaqing423.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"japanesepornav.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yaboxxx8.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qz11app.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.patechen.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.maomaiv1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"55758.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby1179.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kdh.138.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cc138001.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby1259.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwgdian5.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"garenanow.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hy7q.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10m.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0mnitban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zooxhamster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"n2hg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"seedrix.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yldmch.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mg33v.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www44kkmm.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.huocoin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"system.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aqdyap.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xiaomiwz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www976www.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qieziloveu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vtcto.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"358222.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54bba.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yigaywan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fhcp2288.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8x1078x.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bankhapoalim-login.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.madou05.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"login.77boc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwnkh60.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xm888uu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.389mu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.52xsba.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"12889.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.1.gps36524.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ag1351.cx5668.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xy3335.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gun.mi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.raku188.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"download.ninzhidata.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.myqcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"okxxzy.xzokzyzy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"web.raku188.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"shenmulin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"724yw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wmhsmkk6-www.vkzzz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xincs999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.shop055.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"k8cp01.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"25200.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"web.xlvx88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.6122.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.feifantxt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jwcj111.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.520hei.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.w9155.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hg8088.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.4438x8n.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw33318.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"173.fangxingggc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1181.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"punggung.quantum.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.c4carab.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xxh188.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.wcwc33.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zhipei365.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.baoyutv1113.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.101012345.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hxsq8.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"397hh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tpp100.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"homecdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hhfgk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tencentmusic-eng.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@" jinanm.fhqbl.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77719.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www247yy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gc.vpcdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.caoxiu25.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"all01.baidupcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gt.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4bwk77.hdovip.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kichikudoujin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"7857.xxxdaohang.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zhangjiankouzhaopan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"loy999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bluetwo.myqnapcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.f2dzy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.shaoxiu272.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nta777.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@" xhamrt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.aygj668.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xycp1011.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yetaqu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bt8088.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"w2vns.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"welcomejc88886.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mmstat.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www237cf.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4hu93.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.999uu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.624d.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"92pao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"009149.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"85.pao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"30gao.pao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"300js.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwcaoporno.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.waka-epay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.feichengrencai.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nissanofnj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.25sk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"av7777av.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4488b.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www4488b.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hskjfk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vbo.1rfang.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.woyaodafeiji.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.bbs.eflye.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"77966w.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"picture.fivlay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pururin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jlhz004.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.llhuu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jjdong6.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.betstar999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"rexxar.yygslb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8x8x.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sts1073.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"b47w.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"880778.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"es1.pointtoserver.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.iavzzz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby77731.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5yt8888.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huasea7.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"asusleng.asuscomm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kkss00.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.51365.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"shmail.ibeisen.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"naping.globh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mp3anthems.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sxs17.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"66uouo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"v2.xw0371.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.av7125.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77732.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"626hs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.8702.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.584bbwww.584bb.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"maduotv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ebchina.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www-97ai.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"18avk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.njnjr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.032966.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"18homic1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1332.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hall.qkagame.com.wswebpic.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vrqjwd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.cskpw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sesiji55.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sxzte.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by11173.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mscp999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.52kanbi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.myreadingmanager.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.aqb3366.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"41ssu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"deepinstinctweb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lululu84.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xxanbang.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"joker2929.net.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pushbt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.365gj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hbpaomoboli.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bnutest.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.my877.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"connect2.joyglobal.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kuangex.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.2238h.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dioguitar.22366.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.9978.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51tqt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jr.erocooi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"chunjie.baike.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"taojingk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.756hz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zh.erocooi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1195.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"libue4.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lobby.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lessrecoil.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"genhem.yeyaguanc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"libcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"beauty-and-success.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"libso.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"libbugly.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lib.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.wcecp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"paks.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"magibullet.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yiren127.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"root.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"virtual.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http8xui.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zhubo740.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw8815.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw33316.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bbs.vcb-s.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dto67.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"7dog.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.21ruru.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"youtute.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bx77222.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"233mc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pz07.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www182tv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fip.cscec.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www299hk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sj8av.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cn.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcdn.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yaokan.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ak3356.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"detect.bot.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"client.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.dccp9988.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ysen33.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"krafton.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dfcp11.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"276132.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"87234444.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"55550004.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"esp.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kuroyama.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.jlcp111.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sdyl688.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pc66520.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52scqs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yh78917.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"shengbet88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hscp6611.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"client2.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zwww.wc9955.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"norecoil.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"77058080.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.downxia.12mma.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qq.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ysgj60.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.i9077.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hscp23.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"77059393.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.ysen66.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"x8games.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dccp9988.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ant618.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"speed.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.g6566.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xr1386.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zelmante.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.hqcp55555.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www2322.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pt1386.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xino38.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xino18.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1196.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.oapif.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"quanbiw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"globalsofunny.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51findbook.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1181.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"globalsofunny.sausage.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jqxiu442.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.3333papa.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"d012.g02.dbankcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.248qs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.5k43.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jiaoyakong.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"avnyg3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jing2005.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.msm4all.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sex.corephi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by66626.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by77756.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mix.kozow.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw9916.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"av79sex.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1178.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"koreaxnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1257.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77712.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.535pp.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"appimg3.hicloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by7751.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77718.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.animeidhentai.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw8813.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tn-young.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.918kiss.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.cpdd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.youwu666.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ssstiktok.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vip9957.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1257.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huarenx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tnlama.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.avtb2049.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dm.1.918kiss.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby539.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xvideos.boypaly.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"11xxtv.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"01.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"234k31.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.789abc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xvideos.comwww679922.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"connectivitychck.platform.hicloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"live.livemakerpro.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://live.livemakerpro.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://live.livemakerpro.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://live.livemakerpro.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.7.129.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://96.7.129.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://96.7.129.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"akmwebstatic.yuanzhanapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://akmwebstatic.yuanzhanapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://akmwebstatic.yuanzhanapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://akmwebstatic.yuanzhanapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.shuiguopai88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.shuiguopai99.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a1904.v.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.rbet999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dl.codm.cdn.garenanow.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"images.nortonline.com.gr"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yilingindonesia.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hapag-lloyd7.azureedge.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"repprod.azureedge.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fp-as.azureedge.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ronghan.azureedge.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"assets.cnhindustrial.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.235.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://184.28.235.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://184.28.235.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.51.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://184.25.51.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://184.25.51.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.248.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.188.36.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"103.254.188.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"218.1.70.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.240.60.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.149.151.156"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"down.anticheatexpert.com.wsdvs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"douyu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"i0.hdslb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.douyu.com.wscdns.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"speed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://speed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://speed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://speed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"naspeed.igamecj.com:17000"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://naspeed.igamecj.com:17000"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://naspeed.igamecj.com:17000"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://naspeed.igamecj.com:17000"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a.top4top.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://a.top4top.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://a.top4top.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://a.top4top.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.194"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.206"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.161"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.199"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.203"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.205"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.207"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.209"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.197"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.204"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.200"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.198"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40.120.0.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"me-du.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://me-du.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://me-du.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.21"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.15"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.4"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.5"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.12"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.6"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.14"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.37.82.7"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3008-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://3008-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://3008-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://3008-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.14.20.156"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.14.20.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.14.20.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.14.20.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.14.20.153"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"45.40.220.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"45.40.220.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"45.40.220.70"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.191.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.139.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.186.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.129.175"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.57.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dns6.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fileserver.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.com.tencent.iglite.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tancentgemes.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host.block.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1pubgmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host.qq.com.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"git.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ntencentgames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gameloft.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.167.221"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.236.165"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.126.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.67.112.132"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.96.5"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.198.174"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.57.139.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.176.145.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.7.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.237.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.13.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.34.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.48.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.161.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.208.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.162.236"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.53.95.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.177.243.193"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.249.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.1.241"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.50.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.31.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.195.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.255.15"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.80.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.38.129"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.146.21"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.92.136"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"50.18.198.249"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.83.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.86.135"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.169.225.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.185.177"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.175.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.53.60.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.2.175"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.151.29.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.219.116.0"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.77.255"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.153.38.177"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.131.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.83.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.52.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.150.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.81.141"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.103.150"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.65.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.75.153"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.53.117.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.67.128.255"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.176.30.188"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.139.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.53.50.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.174.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.153.15.169"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.78.248"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.208.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.87.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.109.102"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.192.254"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.227.77"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.25.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.39.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.229.248"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.169.210.188"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.44.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"recent.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"adserver.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"com.rekoo.pubgm.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"apse.s.ludashi.host1.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pupgm.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"supercell.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http.tencentgames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"alpha.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mysql.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tecentgames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"linux.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"svn.tencentgames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"help.krmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.246.244"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"the-file-coverter-"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"android.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.149.133"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencentgames.helpshiftencentgames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"murka.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"102.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"activision.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dsasa.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ipubgmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"galxyz.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"critical-force.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"epicgame.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tbstnt.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anghami.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent.games.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubghacking.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nsa.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"playmc2.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"syslog.pubg.krmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubglobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yondermusic.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tencentgames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zebramo.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmvn.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"id.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"daisuke2110.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"encentgames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bolegames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jabong.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"server1.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4alpha.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"funplus.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"niantic.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dns20.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"turborilla.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mobilityware.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"stage.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"potatso.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"scopely.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"development.qq.com.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"report.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmkr.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"krmobile.com.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgkorean.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.report.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mta.pubgmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ban.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"noban.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ban3.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmgl.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ads.block.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"smtp.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host0helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host1000000000.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host1000000001.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent.block.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent.game.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vm.pubgmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tristan.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"stats.block.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"seated.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qookagames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pingmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host2.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.219.145.134"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"50.18.214.151"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.53.147.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.133.98"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.57.163.172"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.155.137"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.97.192"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.135.151"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.78.225"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.215.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.153.39.137"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.27.129"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.41.62"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.34.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.212.21"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.129.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.227.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.238.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.95.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.253.86"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.33.162"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.166.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.52.140.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.53.39.70"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.34.78"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"50.18.220.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.77.71"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.197.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.151.209"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.72.17.198"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.239.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.201.88"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.52.193.162"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.104.209"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.239.254"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.215.71"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.219.244.54"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.94.165"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.57.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.151.70.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"204.236.172.151"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.198.215"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.171.187"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.104.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.79.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.241.185"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"204.236.188.147"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"50.18.27.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.57.122.231"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.199.3"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.210.243"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.105.238"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ubgmvn.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dns0.block.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dns4.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"08games.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dots.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"glumobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.112.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.112.95"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.112.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.112.172"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.112.247"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"94.191.67.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"154.16.63.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent-cloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencentcloudapi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"onezapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"amazonaws.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"154.16.63.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"core.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"capcom.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lag.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"quantum.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lightspeed.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"epicgames.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"twimg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tunnel.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"shield-tunnel.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wenwen.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"myapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qzone.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"soso.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"midasbuy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"google.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"adjust.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"subaogame.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobile.kr"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"battlegroundsmobile.kr"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"appspot.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"googleusercontent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobile.jp"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dnspod.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloudfront.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"myqcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"awsdns-11.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"awsdns-36.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"awsdns-19.org"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"awsdns-57.co.uk"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kvinit-prod.api.kochava.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"firebase-settings.crashlytics.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"webstaging.sweatco.in"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"naver.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgameshowtime.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencentgames.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"igamekr.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fna.fbcdn.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fordeal.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qos.hk.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hk.voice.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.salla.sa"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"krping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"meping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"euping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"saping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"w5c0.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wy1917.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw8812.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by2297.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my.newroz4g.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"abgx.lanzous.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby77756.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn8.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ip138.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ltdomptp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tpsohotest.dynns.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www-195.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jjj15.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baoyu77751.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1179.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.2288sds.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pic.bbs.paytoutiao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.4401a.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cangtt53.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1335.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cz5h.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"liveali.ifeng.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.dadatu5.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www135yt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by6887.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.78784.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jisu.rktrp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.cheaperword.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"en.preonline.eflycloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.4hu79.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www881xu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sg66999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ckxla.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"miaoboav.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwbaoyu.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xp8866.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mgdc81.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20psychedelicsonline-shop.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"04365365.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xxxkaka.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72966p.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"stores3.hispace.hicloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"beetalkmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8x5a.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huangwangooo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.galgamezs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www-xvideos2-com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.555888666.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xxxiva.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www5201314.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"297q.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"eunex.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www130mk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.194zh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pay.team-demo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.hga.030.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.59hhh.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud2.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"reporttencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yaodushu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.di4se.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ll0l0.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.guocai1888.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"6969xj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dns.weixin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vpn.ikta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.255ju.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hkshoplist.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.pdlmm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwmaomi59.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www141jj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"down.qjwed.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jinzuan707.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ldwsdp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.69iiuu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.050x.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.9955jing.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"httpsixxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"download.3hfe.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.3hfe.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"chia-anime.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.bluehole.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bluehole.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8zwc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"topgslb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ip-pool.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"googlegoogle.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn7.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn13.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kf1.orangesgame.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn28.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn25.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn30.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn31.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn33.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn14.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn29.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn11.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn100.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn1000.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn10.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn12.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcpconn1.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.rr77ee.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2zd2z.bossppe.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kcam91.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kualm90.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"com99thz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jjszy3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dkdk8.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"771671.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by6692.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5g00bo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ssd.tcd.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcdn.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcdn-svn.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.tcl.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tbi.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dev.tbds.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proxy.example.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tc-svc.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51pppx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"18pussyxnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vip.jf3355.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xxxavel.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huazhousj.cqluoxuanguan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pcgame.cdn0.hf-game.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lzty106.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zgsh.sinopec.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baoyu121.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.skyfire.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nudexxxvideos.japponese.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xppmh96.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ss-fast.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www-398777.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cjfhgz.bjjiamusiw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ww-99hg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"galgamez.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pub678.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"027005.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10min.pubglite.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nkm810.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"waifuli.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"27xxtv.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by.77718.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ebo58.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mirrors.aliyun.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1151.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.53mtpp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kkw0088.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwyw8815.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qg.sqxha.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"resolver8.opendns.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.201ui.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"iqiyi.zuidameiju.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.290sp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zmuu1.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ytimg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.143.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.177.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.183.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172.81.230.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.148.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.67.236"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.130.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"118.25.34.181"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"124.156.123.137"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ig-us-login.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"159.138.214.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.80.117"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"159.138.215.102"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"159.138.215.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.82.7"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.86.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"159.138.212.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"159.138.215.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.84.124"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.86.198"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"159.138.214.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.84.205"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.81.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.86.69"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"159.138.214.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.193.239"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.194.69"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.193.253"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.189.205"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.199.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.199.184"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.193.254"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.193.229"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.199.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.199.207"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.113.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.113.159"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.117.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.121.150"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.113.77"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.113.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.113.117"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.113.80"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.113.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"191.235.113.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.194.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.193.251"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.194.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.194.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.189.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.189.206"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.193.231"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.57.193.240"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sa-sap.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"saping.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1005-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"170.106.102.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"na-west.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"170.106.102.137"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"170.106.102.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"170.106.102.162"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"170.106.102.245"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.38.135"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.38.14"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.39.193"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.228.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.33.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.41.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.230.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.46.181"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.229.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.41.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.36.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.46.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.41.229"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.38.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.228.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.244"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.239"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.184"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.137"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.186"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.200"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.214"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.135"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.140"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.222.69"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.158"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.229"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.246"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.145"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.156"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.48.254.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.69.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.69.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"7001-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5002-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"me-iraq1.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.69.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.69.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.69.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.69.79"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.64.191"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.69.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.69.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.66.221"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.65.247"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.65.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.67.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.67.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.65.175"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.64.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.66.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.67.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.67.143"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.66.219"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.65.212"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.66.150"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.64.207"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.64.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.67.37"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.65.240"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.64.61"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.64.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.65.206"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.135.71"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.183"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.135.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.135.200"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.193"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.132.132"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.134.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.134.162"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.133.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.137.196"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.135.87"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.199"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.133.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.137.133"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.137.220"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.137.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.135.174"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.135.237"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.247.135"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.158.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"krping.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.163.52"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.83.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.81.175"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.240.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.83.215"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.231.99"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.243.140"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.235.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.237.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.239.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.84.124"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.83.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.243.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.153.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.235.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.81.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.84.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.158.141"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.157.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.234.191"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.240.159"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.230.61"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.232.216"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.191"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.131"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.142"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.99.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.99.150"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.143"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.241"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.199"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.218"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.213"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.138"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.180"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.205"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.203"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.243"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.207"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.194"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.174"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.99.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.56.161.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.27.180"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.25.251"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.27.79"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.13.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.97.243"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.26.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.25.248"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.27.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.138.218.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.138.221.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.26.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.27.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.8.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.26.98"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.13.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.12.230"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.138.219.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.138.219.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.97.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.74.27.151"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"7003-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"eu-meping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.143.230.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.11.25.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.49.245.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.49.244.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.143.238.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.143.229.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.49.247.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.49.243.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.49.143.245"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51.143.230.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.99"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.98"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.102"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.117"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"20.47.95.88"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.240.13.14"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.240.218.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.240.217.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.240.7.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.240.25.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.42.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.130.63"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.3.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pay.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"os8.api.unipay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"spay.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.201.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.29.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"81.69.156.205"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172.81.231.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.147.162"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.131.166"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.109.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.183.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.134.54"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.171.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.156"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.81.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.81.237"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.81.87"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"euspeed.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"euspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.229.113"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.129.54"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.130.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"79.124.78.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.gsdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud2.gsdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proonxx.1717yaoshe.co"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xvideos.61q2.co"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ucmgg.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mntban.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.tc.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubghacking.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibankr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"alog.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent.ig.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https.asiansister.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10menitbann.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearban.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anteband.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgantiband.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearbanigamrcj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearbangclouds.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minbanigamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"banjia160.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"down.ggiptv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"igmacz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent.cloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkconfig.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.euspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"d4file.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"accounts.app.adjust.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65-hkping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"f7gcloud.download.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"end.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ping.asia.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"file1.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgglobal.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cmn1.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"krtencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheat.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"actencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zip.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ac.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mtp.anti-cheat.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloudvoice.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antireport.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qqgame.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgtdm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vmpcloudconfig.json.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"autoheadshot.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.11.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proximebata.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"file.100.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkqos.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.pornhub.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10min.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"defender2.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"combosakti.telkomsel.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearpubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xxnx-xnxxnxxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"csoverseas.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"clouds.gdsk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"91klive.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pandoragame.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.dsdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tracker2.wasabii.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dpo.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"idconfig.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"clound.gsdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearsban.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cheat.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proximbeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ig.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minban.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearban.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ios.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"conectivitycheck.gstatic.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hawk.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mimutelevivohcias.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"strange.vpn.host.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ww.xnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkconfig.gc1oud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yy.xnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"csoverseatest.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cstest.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lightspeed.tencent.ig.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"flash.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"japan.www.xnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.proximbeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1000qq.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"banned10minutes.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"crack1by.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yarsban.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"com.tencentanticheat.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubglocalhost.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgmobileseason13ipblock.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minutes.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kraftongameunion.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"us.vpnkaka.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"githubusercontent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mntban.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobillite.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qq.www.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"speedws.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"detected.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xnxxdog.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lessrecoil.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14meping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1007.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anitcheat.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lessrecoil.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mntban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yrban.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anti-band.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"igamerj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"shangmao.baidu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"blockplayer.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgfile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gamecloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"com.tencetig.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobile-cs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"robertpattinson.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgserver.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1-down.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgm.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkping.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobilekr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied.tc.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubglite.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"freefire.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"id.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bug.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bypass.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gameguardian.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1pay.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"report.mail.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ntl.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"singapore.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"administracion.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"akamai.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hostpubg.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"th.pornhub.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qichouchou.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"idping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"service.joyoung.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bugly.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud1.download.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antiban.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibaned.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dcloudstc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proximabeta.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"club.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"inti.mtp.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mail.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vip.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"backup.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lab.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"auth.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ktcdn.ngame.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"policy.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied.1.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gay.pornhub.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"polecy.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"beta.tencentgames.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proximabet.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobile.cloud.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmibile.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgmobile.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1krping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubm.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gdsk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nobaned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ipv6.vng.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gsd.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"groo.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ip.block.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ig-us-askapi.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"crashreport.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"natc.ngame.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antichaet.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mimutes.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"androidbugly.qcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minban.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheatoff.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"krpubgm.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibanned10min.tencentgames.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tencent.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wallhack.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.mobile.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mntbanned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.110.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hksggd.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"reportplayer.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"asia.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"eu.pay.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ipv6.msdk.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"report.mtp.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheat.q.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"broker.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkspped.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cheetahvpn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud2.download.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hostbypass.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hostvip.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"block.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"beta.pubgameshowtime.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkconfig.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10min.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgkrantiban.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent-server.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloudobjectservice.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ig.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"scrpt.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hksgspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lobby.igameci.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"developer.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.gadk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"saping.ig-us-"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sdkapi.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"edukasi.ruangguru.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aa.pornhub.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"security.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lgmecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgcheater.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bartxvpn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheat.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qookkagames.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host.txt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nobanned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.aimesp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"feedproxighs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"feedproxi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"napubgm.broker.tplay.ag.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"clould.gsdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lobbypubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vip.dangerous.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"recoilpubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antinaban.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bankbbs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anti10minban.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"develover.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"measurement.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud.download1.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.mtp.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10year.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.cloud.mtp.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proxibeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bypass.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"app.measurement.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antideteksi.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hostmaster.akamai.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yourhost.example.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0helpshift.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubg1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn-pubg-season-11.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibanned10min.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zone.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pai.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yrar.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"logs.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"autoheadshot.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anteban.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mnitban.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"conquerors.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2019.apple.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"haker.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"9speed.gsdk.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn111111d18.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"msdkpass.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheatbloc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"down.kfstlzx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qcloud.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yastqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"no.data.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubghackfile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencean.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anitcheat.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"java.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgcheatcode.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"support.lite.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1010.qq.com.cloud.tc.napubgm.broker.tplay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"webmaster.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgkr.mobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tc.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tdnsv6.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"midasoversea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.kr.mobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied.tcqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.tcqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pybk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgm.kr.mobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qq.mobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied3.tcqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied1.tcdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pungmobile.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"file.igame.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied2.tcdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubglite.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.vipbyw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bypass.vng.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgdns.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"riportingame.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied6.tcqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied3.tcdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bypassqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"twpubgm.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubghost.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"crownpubgmobile.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"security.miui.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"no.baan.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"rok.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgdata.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vnpubgm.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearbanned.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"res.100.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sharpshooter.key.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlited1.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgm.mobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"clientbeta.pubgameshowtime.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3rdparty.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3dparty.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"report.pubg.korea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qcould.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"driftcdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ate-limited-proxy-108-177-64-"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qqqqqqqqqqqqqqqqqqqqqqqqqqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobileclte.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"domain.cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1041843992.qzone.cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153389523.qzone.cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1.418407929.cs.gcloud.cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tab.cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4006831238.114.cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zzlm.cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"309827756.qzone.cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"helpcenter.teklabimsight.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hksspeed.igamej.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkg3.facebook.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn49w.haier.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubguser.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloudtencen5.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"securityconfig.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xnxx18pussxnxxyxnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied4.tcqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied2.tcqq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dragon8.troyhero.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"asing.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"asping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ip.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qq.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pm.bogmating.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"x-vnglobby.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"twlobby1.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"home.iavbobo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"web.antbang.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antireport.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"beuping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"s3.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied.tcdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vbyte.qcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloud.pubgkr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"na.pvp.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobil.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobile.tenchent.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubobile.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"local.host.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.cloud.mtp.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"g-us-sdkapi.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ngame.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheat.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hotcool.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"igmecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"developer.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jinbang01.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobie.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobili.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hack.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ns.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cs.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"game.safe.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tencent.com.google.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearbanbed.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zoo.xnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"astar.bugly.qcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgkrhack.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5ed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xbmm10.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jackieperez11yahoo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.feiji11.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cont-ch1-1.pandora.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"paks.pubgkr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www6652h.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"audio-ch1-t1-1.pandora.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3clu.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cjy05.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hhpp.xnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mp4.238yy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xianhedy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http.javbus.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.a1dy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hotwlfexxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kj-se-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://kj-se-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://kj-se-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://kj-se-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://kj-se-shadow.igamecj.com:9031"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sa-sap-m.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://sa-sap-m.shadow.igamecj.com:9031"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://sa-sap-m.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"as-hk.shadow.igamecj.com:9031"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://na-west.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://na-west.shadow.igamecj.com:9031"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ios.bugly.qcloud.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.0.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"file.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://file.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://file.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.51.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.56.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"35.244.243.153"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.81.169"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.51.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.210.215.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.195.46.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.195.46.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.129.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.78.140.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.59.168.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.23.167.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.23.167.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.225.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.7.129.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.56.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.7.129.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.81.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.238.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.248.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.211.136.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.87.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.50.137"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.44.51.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.252.224.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.248.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.87.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.199.54.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.199.54.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.78.140.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.11.213.142"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.11.213.151"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.98.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.37.125.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.37.125.193"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.238.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.78.141.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.206.215.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72.247.211.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.238.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.238.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.2.16.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.35.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.78.141.88"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.237.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.237.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"63.217.233.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"63.217.233.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.114.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.114.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.223.56.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.88.70.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.88.70.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.63.243.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.63.243.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.45.177"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.45.186"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.27.122.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.8.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.55.166.162"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.33.95.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.55.166.172"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.16.106.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.224.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.218.94.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fpie5.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.fox5atlanta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.nic.in"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ba66.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"card.navgujaratsamay.indiatimes.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"eaassets03-a.akamaihd.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sportsnet590.ca"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.bestinto.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"download.hopewinner.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"shence.jiushengliye.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"i1.market.mi-img.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sdk.sascdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"file.igamecj.com.akamaized.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"760889.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dafa994.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.minecraft.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdngarenanow-a.akamaihd.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sgp1.info"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"d1.xboxlive.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yc9789.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"planonar.enourredoo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"klive-a.akamaihd.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"riot-client.dyn.riotcdn.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a1089.dscd.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"storeimg.heytapimg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dbltap.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a.akamaihd.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intldlgs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intldlgs.qq.com.tegsea.tc.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intldlgs.qq.com.edgesuite.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.gameflier.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"file.igamecj.com.cdn.ettdnsv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a1967.v.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bcsecurelivehls-i.akamaihd.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"st.w.xk.miui.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"garenatw.patchcdn.pathofexile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"espndeportes-"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"play.barney.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.mobilelegends.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aac.saavncdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn-accedo-01.akamaized.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"na-east.shadow.igamecj.com:9031"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://na-east.shadow.igamecj.com:9031"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"na-east.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://na-east.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.50.48.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"158.177.68.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.50.48.198"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"169.50.48.196"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"com.tencent.iglite.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"recentgames.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aulaup.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ads.pubg.krmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"131.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gruupmeet.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgmvn.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dns1.pubg.krmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"87pubgmvn.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99games.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"administration.pubg.krmobile.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"apache.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"50.18.16.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.106.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.206.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.176.203.78"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.174.149"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.192.212"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.53.61.192"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.192.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.65.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.57.166.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.57.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.57.122.149"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.lp.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"playrix.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"svn.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"napubgm.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgm.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"host3.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wohands.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"robinhood.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fjuul.helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://5002-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://5002-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://5002-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"eu-fra.shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.132.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.133.188"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.132.61"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.138.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.138.191"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.237"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.132.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.135.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.134.141"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.132.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.138.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.132.230"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.137.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.136.238"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.133.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.138.184"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.138.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.137.223"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2006-shadow.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloudctrl.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://cloudctrl.gcloudsdk.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://cloudctrl.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.235.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.233.174"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.247.206.172"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.192.202.177"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.86.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.122.185"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.23.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.txfund.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pingtas.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lct.avictc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qian.ehowbuy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tencentwm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dsale.ebtrust.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sgpcloudctrl.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"w.gamecenter.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wx-credit-repay.tenpay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"g1.crm2.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"c.tenpay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bisheng.tenpay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cloudctrl.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baoxian.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"access.video.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tunnel.video.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hs.ymssg.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qian-img.tenpay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huodong.zb.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"connect.play.aiseet.atianqi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"im1.b.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"doctor.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"promreport.crm2.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"agpolis.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ssl.gongyi.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wx.qlogo.cn"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"thirdwx.qlogo.cn"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cwx.qlogo.cn"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.4.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.244.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"115.159.75.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"118.89.139.38"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.157.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"118.89.152.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"115.159.92.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.154.187"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"115.159.100.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.227.160.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"140.207.69.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.184.238.102"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.135.169.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.234.156"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.232.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://www.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.238.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.27.122.80"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.56.138"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a1887.dscb.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgmobile.com.cdn.ettdnsv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a1845.dscb.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sf16-scmcdn-va.ibytedtos.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"download.eudemonsonline.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.brp.cn"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"asrvvv-a.akamaihd.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"review.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.crzytsy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn-assets.gamesamba.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.rne.es"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fpdownload2.macromedia.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"content.corel.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.farnell.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111vod-adaptive.akamaized.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a1051.b.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hendrickmotorsports.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.bilii.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gyc8888.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cstat.apple.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"init-p01md.apple.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ncc.avast.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"openwifi.ucweb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"it.insideover.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8626c.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"p16-va.tiktokcdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"play.hbomax.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sgptv.co"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"areude.kathilag.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"en.nickelodeonarabia.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.thegatesnotes.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"static.yximgs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.eusu-logistics.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.adanak.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgmobile.in"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.doosanheavy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"reality-stream2.akamaized.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.iefimerida.gr"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.herogames.com.tw"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"video.ruangguru.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgmobile.com.edgesuite.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.avidblogs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.blogseitb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ireachcontent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.cf92.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"emea.mitsubishielectric.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.prnewswire.co.uk"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kartell.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ww1.microchip.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.johnsonsuisse.com.my"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.claro.com.sv"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"abpnews.abplive.in"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.diariodenavarra.es"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.publico.es"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.toptenreviews.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.haberturk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.harrywinston.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.executivestyle.com.au"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fiat.mopar.eu"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.prnewswire.co.in"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.chinatimes.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pcmobile.ca"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ph.nec.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.allnet-italia.it"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"booking.lan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.gmchina.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.avg.org"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hub.bd224188.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.louisvuitton.fr"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a1386.dscb.akamai.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.56.140"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.72.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.56.199.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.211.140.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.238.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.210.215.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.75.169.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.55.56.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.55.47.222"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.18.213.153"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.199.34.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.215.177.147"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.215.177.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.34.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.34.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.129.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.37.227.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.37.227.136"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.229.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.18.213.216"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.129.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.248.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.35.98.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72.246.103.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.34.224"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.34.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.91.68.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.35.98.74"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.72.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.88.70.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.27.123.200"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.87.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.248.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.248.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.87.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"173.222.148.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"173.222.148.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.223.198.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.223.198.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.241.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.204.147.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.8.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.8.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"69.192.217.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.35.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.35.171"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.40.243.186"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.40.243.171"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.129.113"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.129.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172.232.44.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.33.95.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.33.95.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.213.168.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"69.192.217.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.91.69.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.203.135.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.212.109.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.91.69.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.8.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.203.135.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"42.99.140.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.114.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.241.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72.246.103.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.248.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.112.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.90.7.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.90.7.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.204.152.37"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.91.68.130"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.89.124.187"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.20.244.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.20.244.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.72.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.194.116.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"95.101.2.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.237.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172.232.10.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.237.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.88.70.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.56.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.211.140.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.52.171.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.52.171.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.194.116.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.194.116.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.52.171.98"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.123.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.123.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.27.123.169"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.72.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.72.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.72.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.171"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.147"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.123.219"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72.247.184.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72.247.184.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.48.201.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.218.80.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"63.217.233.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.199.54.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.199.54.80"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"92.122.192.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.153"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.84.150.188"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.218.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.127.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.127.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.84.150.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.34.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.34.147"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"92.123.140.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"92.123.143.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.11.206.169"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.11.206.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"92.123.245.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.51.0.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.51.0.249"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.33.95.137"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.56.238.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.56.238.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.15.138.189"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.61.244.184"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.9.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.115.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.9.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.241.88"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.63.74.150"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.63.74.199"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.221.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.74.15.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.74.15.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.89.124.248"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.221.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.56.201.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"88.221.113.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.78.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.57.66.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.221.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.221.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.215.102.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.238.88"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.204.147.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.218.94.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.218.94.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.221.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.211.140.147"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.87.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.2.16.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.116.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.56.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.219.172.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.112.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.112.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.112.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.62.54.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.113.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.62.54.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.116.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.123.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.123.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.123.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.50.216"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.50.145"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.61.244.138"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.7.251.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.44.51.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.44.51.249"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.56.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.56.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.211.136.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.77.204.153"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.91.68.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.91.68.240"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.197.49.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.46.229.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.197.49.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.200.74.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.54.82.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.78.32.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72.247.184.161"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.2.16.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.232.190"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.232.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.2.16.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.211.140.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"45.64.21.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.54.81.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.54.81.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.235.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.83.4.129"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.50.232.192"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.83.5.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.27.122.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.229.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.221.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.56.219.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.205.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sg-tdatamaster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://sg-tdatamaster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://sg-tdatamaster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://sg-tdatamaster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"commnat-main-gc.ess.apple.com:16384"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"commnat-main-gc.ess.apple.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://commnat-main-gc.ess.apple.com:16384"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://commnat-main-gc.ess.apple.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"idcconfig.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.235.68"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.167.154.21"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.44.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.206.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"web.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sdk.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dl.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cgi.qqweb.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"web.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.console.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"consolev2.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"speedm-team.tga.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"app.tga.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mspeed-op.tga.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"op.tga.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud.tencent"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hpjy-op.tga.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wecard.tenpay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"global.cschannel.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"csoversea.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"csoversea.mbgame.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.143.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.231"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.143.247"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.142"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.1.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.3.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10012.ecport.vip"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10012.03boy.cn"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.143.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.143.171"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.32.143.142"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.37"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.220"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.0.38"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.3.213"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.69"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.0.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.3.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.121.174"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.29.150"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qos.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.35.248"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"118.25.167.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172.81.232.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.35.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.129.149"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.51.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.51.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.51.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.51.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.130.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.145.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.147.69"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0.0.0.1"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0.0.0.2"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sandbox.pay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.3.235.71"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.6"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.12"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.7"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.14"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.15"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"185.151.204.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"178.162.216.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"178.162.219.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"178.162.219.61"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"178.162.219.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"178.162.216.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"178.162.219.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"178.162.216.180"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"178.162.216.177"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"rqd.uu.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://rqd.uu.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.239.188"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.239.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.166.150.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.168.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.168.140"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.88.185"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.166.150.140"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"113.96.208.117"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.204.16.140"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.239.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.241.17.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"113.96.208.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.204.16.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.88.184"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.253.217"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.23.159"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.255.173.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.255.173.159"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.23.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.146.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.29.42.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.29.47.192"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ios.bugly.qcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wzcompany236.xabcgg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"p.ynb2dca.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ystball.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.drf8888.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yp.gunhe.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"onhenan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baoyu193.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kk2233.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huiyutcc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by6135.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.gpsjm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.99yuce.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hdhwi73z.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"haicaotv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kcai555.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aqqaqa.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4hxx544.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"livejieyang.chinamcache.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sexiu430.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zaixian-fanyi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.paypal.xoom.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ucmorgan.xoom.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"boc.xoom.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"paypal.xoom.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.javbt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yuesp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"918kiss.agency.login.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www18comic.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"35pqao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"beikefuzuo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ldgz.ceair.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ibet369.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aiqingdao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.crmg-as.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kaolamao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dizhimail.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yuese79.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www2rb2rb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vns7111.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"thd6699.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kpndh7wgfqr6kilq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by177717.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"88654.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cpdd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ruru84.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bosbjcdn.bpc.baidu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmatic.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.kanghuayun.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"meinvzj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ettdnsv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gvt2.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my77738.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.3z9w.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.18avd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"atianqi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"swk777.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huo119.mynetgear.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"boying3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.1yexf.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by5266.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gupfiles.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud.globh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ad.yz9191.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.66666uc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ntp0.aliyun.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my1159.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.7zmq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"66138777.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xn--wxtr44c.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"s1.go2https.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"miya768.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.maomiavdy.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.nuezhilian003.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1178.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1131.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jiq337.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby7783.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zzzav5.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2022cmx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zzzav4.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"httpby1259.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"e-hentai.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xnolim.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.sbxs3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sifangtv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.524tu.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hrdav5.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw1126.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cn.porumb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.188427.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"uw195.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"buttonbeanies.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.my1165.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by1135.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.freeporbvideos.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mg5528.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.baoyu131.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"00uu22.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"32bt.pubgemobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"osxapps.xunlei.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.120cxsg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.nilaipa.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mvp323.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw1126.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yrf6.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1112312.lolita3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gqqsm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yw99996.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by5121.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www444ae.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gaoxing99.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"videos.kkyun-iqiyi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.i8i88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.007ao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"st.stripcdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"javbus2021.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"64423.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proximebeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"x4bb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"93tx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby1227.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.999e.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dcttotal.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwxmkk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.seyeye7.comwww.seyeye7.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xhongxing.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ts-corporbank.zgcbank.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.886pi.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwfilmpornfree.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hgxin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.mm6666.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"temcnt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"01995com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"p.vxotu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.v2wo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.aa65e.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.byb366.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vvww.ysybyb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sdswf.512514.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.shaoxiu169.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"idiyiqiyi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lieqinews.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"777avxxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"778218.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.9911.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pu690.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwa.lanzous.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.live.newhnewe.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5377w.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tengtengse.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bj697.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yobe123.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www69apv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"510288.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud.codm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"network.block.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anti.cheat.block.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.website.block.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.zzhg888.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"q2306.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.qq.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"server.block.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dehui.pztuan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.p9393.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"january.ixinian.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ip.qq.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.qiuxia88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.myx2882.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1dayban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zhangxingtg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gl.pubg.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dpsrp.plugin.qqgamemi.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"report.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vip1.ba99999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"j8today.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dopa9.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"h5hosting.hicloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"56smm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xxhu8.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.se94se1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"youku.cdn2.youku.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"51wtp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"18waimao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zhuan.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zzz.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wearered.myqnapcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zone.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ywts.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"android.clients.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"storeadmin.zapya.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tpns.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"freq.m.tpus.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tpshell.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tpx-01.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0101home.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tpush.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xy030.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"redirect.cache.tpush.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tqos.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tst.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ucloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"91ccz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tss.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"unban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"web-proxy.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"whoiscloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4kkpz.0-photo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kid.v.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sifangclub.net.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"rhino.acme.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mobileapi.gree.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.zfbill.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by2286.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by2286.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw9922.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by88817.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lo2p265ca0175.gbrp265.prod.outlook.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.lianxiu150.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"973209.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tom960.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"live2888.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwkpd120.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw875.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xby78.sg66999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"oiasan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lianxiu228.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ikta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"awcode.cn.verygslb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"amazon-adsystem.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yaokan.tv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"actives.youku.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yiyan02.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"imrworldwide.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kisslink.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lufcb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tttzzz28.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dddfy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"feel-roadusa.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.btexe.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"singing.xz.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"666.kkq688.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hr18088049999-wwwhjw1688.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"amazon.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"798.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ameguardian.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"434kk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.manhuafen.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2zea.quanlingsan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"animasi.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anribaned.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"myreadingmanager.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antirepot.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cy6.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"amazona.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8ks9wa.cqrcn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1rer.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www-pornhob.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wangsu3.live.pptv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"backup.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"amazone.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"baidu.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5689.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jxyjmpx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hg888788.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"backlist.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by22.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ail9.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"x.wuxoo4.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aamulehdenblogit.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"all.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"siangapore.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"oose333.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cabin.ceair.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kk6mm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.kd-tp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"adjust.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10-minban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"abhishekranjith.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"app.ywq55555.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"accest.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"122q.lanzous.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lib.tdatamaster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"55uf54.zzsipos.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a.api.riotgames.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intel.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.k85cp11.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"whoreasian.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www1.subic88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.spp.senbafu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ssp.senbafu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.00zone.block.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ccc3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dqjintai.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jlwdj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"codmwest.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.qksapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.fc628.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qqcloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.redmi.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"randy-malware-maugans.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qqasia.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"keepalive.tpush.android.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.637net.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ad.baijiahulian.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"haowg.lgl55.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.365r50.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"7mdizhi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5cloudmx.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.365d88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"24hoursban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.421qs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"44ce.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"7u2s0k.com2.z0.glb.qiniucdn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"serverproximabeta.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99d88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ooredo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"acetest.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.akinometer.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.f2dhi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antibanned.10year.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xiazhu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10year.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xxxav.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ainipa2.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"25599.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dmn.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zzserver.myqnapcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"253dwww.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dns.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a89819.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ban.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"v.1qaq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwpc59.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"g9oo.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied1.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"antideteksi.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1668hk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"12.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"07wwsfaf.chijquan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"headshoot.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wx.zzygcn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"64bit.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"32bit.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"grc666666.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.89s2.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.huiyunton.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"email.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hnxinlun.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pu690.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10.minatban.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jkmxwzeuviatoqy.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"security.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mugmall.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"uu8d.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ww11.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ws12333.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ingame.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zhongyuanwfy.aa.02rui.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ip6.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lobby.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lib.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"java.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.qq.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"00068999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"login.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zzz933.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"com.tpush.android.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kogoole.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"oppoa7.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ddzs688.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"changepwd.lines.coscoshipping.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.clou2d.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http.m.iptv444.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"b.retinavpn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"scan.hack-cn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yfhfp.mama53.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.1043home.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"eu.csoversea.mbgame.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"blog.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bloc.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gamelib.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"12gamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"autopatchhk.yuanshen.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"file.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"media.chinaz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.11xxtv.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ok-jf.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bd.1rxjh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sthlp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.haifanlu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yulezhandian.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yls8818.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubg.mobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kebouwo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lovebbo1.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yt357.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby66618.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.dnsdun.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www557755.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mtlluntan16.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"seegasming.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.jiangnan.edu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.llmlt.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yese371.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"niremote.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yg.picadic.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cancdqts.pinbet88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xuzhou.pztuan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwgc553.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.2342zz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xunhuikeji.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"35ll.szlont.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hnmhw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xfyy126.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jyqp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"napubgm.broker.tplay.gq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zbdclk.msdkiki.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.168bmh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.guomo6.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wangsu6.live.pptv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"laosduude.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.56zd56.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.1405c.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"chaokm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zerobywssd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.plok74122.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"topzihua.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xxav2092.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"apkdown.zcchaifu88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubge.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vnp.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"superbiglotto.3-88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.88ow.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wy.tehjkl.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.thefoolcity.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tingshubao.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.yuntaishuju.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"i3y0x.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tw.vitaratw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"work1.huishangfuli.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hs.jskjyc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"china-flower.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"login.test.ceair.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nb.513renqi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2265.lhf1688.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ww1.a-08.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gg.lvdou369.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ysunion.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gdjingying.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huacheng-sh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kjltj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"40002bet.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.820.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.400rxjh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vultr.com.chinabaodi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xg.tl-3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.hjyjm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"usa.3389speed.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ups-v.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"anticheaton.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mm8368.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.m1.mobilelegends.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"idyjy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ue4.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yy7749.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lisenjiaoyu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.cn.businessyo.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tctv20.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bf.uplayvr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"32btpubgemobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"789eb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0lcve1.xphailan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.q6408.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"32bt.qpubgemobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"losangeleslakersjerseysusa.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"login.universalskyresort.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mynetfans.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0377city.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.yitongjingou.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3p.3p678.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3jru.quanlingsan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwvv33.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sim519.liuliang.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xnxww.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0q1y.quanlingsan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bjct.u3.ucweb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xiaorenxing8.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sy9668.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"followergirinstagram.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.fzwankaw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.i-percussion.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.bjzjzdlxs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.idyjy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cgacha.codm.garena.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"d1.aiyiweb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zc558.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bizmx2.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xinyisou.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yzcmall.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"duxingangj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.wzjzglz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bnj1001.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.jdyule3.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ddb.3dkan.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vodplay.xdysoft.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.tlh.locks-factory.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"llss7.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aqfc06.csluts.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"a.https.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vng.tensent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kel188.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.yilongzf.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"506i88.zzsipos.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hywin168.i5www.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kosungames.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ukf8k6.wfthotel.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xiai06.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www226ci.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"e45.2eb.myftpupload.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ttpaper.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ouhvod.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4wa8hl.zzsipos.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"login.zjzk.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"img.hanjucc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"boyboy19.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cz.ab176.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.moutaibaijin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hentainexus.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"187-175-28-100youtube.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sh.cmge.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"frifir.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"down.saohushipin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"allright.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nie.easebar.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ail2.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xz.fish222.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.ah.10086.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"7jjzyz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"zxxx999.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1zone.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"debug.tpush.android.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.zm-ep.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"is.wps.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mmm789.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"helphift.kr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mtc39.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.9786v.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"eac.mgr.banksteel.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tianxing1234.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ao.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aoba.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ap-hongkong.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aov.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xmikka.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.blok.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"apache.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkshoplist.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"blokchain.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bbs.acg183.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.391k.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"apollo.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ddd.7158.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xpress.cloud.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"apd.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"62bwin.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.791zh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"bkuehole.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"up.block.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jhs-www.edanzhjk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwww.91tv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"agicbox.bk.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52544cd617dc.dahuaddns.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yyaa88.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www212po.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"spyware.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"9755yy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"an.q7ms5zbtbi8w.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"shop.cccc-am.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jp1.ss.zhujiboke.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.406r.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.stevenanime.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.h2m9.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"reverse.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"rdm.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwwww.zhaosaoqi6.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.nanameitu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"net.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.60688a.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.99088822.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hbjayx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www926ya.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"jr.pw968.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"appcache.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ar.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www2020avtb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"kuroyama.ara.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ns0011.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"asia.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ok85.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172aa.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huaseg2.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by77714.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"loulishe88.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby1353.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xweiser.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"88av.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw99995.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"video.1haza.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.qq25474.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ww.yw8815.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"apph5source.qqhrnews.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pickview.globalveiw527.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sh-wisespread.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1st.ecoma.ourwebpic.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.221dd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.fm.castplatform.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.2046.mz.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mengbailuoli.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"aqdydl.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"msftncsi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"uniaswap.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"holababy520.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"banyinjia.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"lc8789.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"macau-slot.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sczvip.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dspunion.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.banyinjia.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xz.vds189.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.by2213.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"5g90d.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwby57739.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.cpnn5.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.nonbartv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"00c8w.raytine28.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.78bbp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.xiannvw.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pull.bd8kd.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.rav74.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ism89.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vmwservices.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"titan.mgtv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"onaliyun.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"8x8o.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.9uu.comwww.asian18pro.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by1239.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www125vn.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.joysoon.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.tok.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yw99966.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"yy6070.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wavetopsign.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pay.ztbaopay.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"my576.com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ceisip.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tianlalu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xmaster14.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sjkmu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"by66636com.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pixiu173.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"98987777.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hdyssmsc.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nnteeny.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.88guaji.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"us.csoversea.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proxima.nie.easebar.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubghacklite.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xxxsexvideox.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ww.javlibrary.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwm.javlibrary.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cs.mbgame.gamesafe.qq.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://cs.mbgame.gamesafe.qq.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://cs.mbgame.gamesafe.qq.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://cs.mbgame.gamesafe.qq.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://cs.mbgame.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.102.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.102.185"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.103.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.3.50.229"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.3.50.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.3.50.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.37.101.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.3.150.213"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.3.50.249"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.37.101.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"114.221.149.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.109.156.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.109.156.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"114.221.149.214"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"114.221.149.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"114.221.149.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"114.221.149.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"114.221.149.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.109.156.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.245.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.245.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.245.177"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.240.199"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.245.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.245.161"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.240.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.240.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.3.150.78"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.3.149.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.109.156.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.240.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.155.245.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"153.37.101.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.190.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.235.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.179.145"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.194.234.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.91.69.223"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"116.128.160.12"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"140.207.69.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.49.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"found-angels.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.agency.playfun77.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.10.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.80.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.135.169.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.128.159"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.103.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cschannel.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cs.mbgame.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ipv6.mainconn.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"av.baoyu188.xyz"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"xvideos.www.boypaly.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tel.exp.omd.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.81.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.80.158"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.81.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.80.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.80.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.142.177"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"162.62.81.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.112.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.110.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"45.40.220.55"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sgspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hkspeed.igamecj"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"82.199.209.12"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pubgmobile.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://www.pubgmobile.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.136.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.153.94.21"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.151.54.226"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.14.99"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.240.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.67.247"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.50.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.67.209"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.254.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.44.55"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.67.12"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.196.187"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.242.174"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.200.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.202.7"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"50.18.223.68"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.132.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.72.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.57.161.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.190.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.67.104.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.25.31"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.109.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.177.239.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.87.172"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.18.226"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.217.222"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.153.66.215"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.233.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.163.55"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.81.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.109.124"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.219.127.190"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"50.18.192.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.57.54.204"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.0.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.166.129"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.84.215"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.30.113"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.177.181.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.53.73.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.82.149"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.115.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.122.183"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.165.150"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.140.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.56.221.229"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.129.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.25.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.42.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.139.203"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.117.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.12.70"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.8.82.7"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.81.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.82.54"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.149.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.22.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.36.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.202.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.77.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"50.18.31.184"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.33.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.231.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.153.29.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.192.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.48.181"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.163.38"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.16.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.13.200"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.241.143.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.219.159.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.227.127"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.53.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"204.236.189.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.169.197.187"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.67.79.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.136.239"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.193.101.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.231.249"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.231.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.235.78"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.8.114.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.215.202.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.20.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.222.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.153.6.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.183.203.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.16.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.52.72.61"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.9.164.204"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.57.108.37"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"config.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hliteping.asia.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobilkr.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"srv.0sdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"helpcmsecurity1.ksmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"report.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"p4svip.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3rdparty.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"0euping.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcdns.myqcloud.com/queryip"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://tcdns.myqcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcdns.myqcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.18.161.126"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sandbox.api.unipay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fk.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sandbox.midas.gtimg.cn"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sandbox.midasbuy.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sandbox.quanyi.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"track.mta.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://gsdk.qq.com:18082"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://gsdk.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gsdk.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.235.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.86.188"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.233.186"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.247.206.181"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.192.202.186"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.128.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"login.raziel.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"webrtc.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"globals.lycqsh.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wesingapp.comvm.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wesingapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"file.api.b.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"login.miku.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.23.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.23.71"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.113.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.122.6"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.108.182"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"150.109.13.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.128.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sgpcloudctrl.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.com-iosday.cn"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.43.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.38.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.165"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.66.225"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.184.221"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"140.207.189.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"210.22.247.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.67.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.204.23.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.144.244.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.25.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.88.113"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.21.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"49.51.66.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.2.63"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.109.90.117"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.58.153.225"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.194.118.216"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.219.132.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.14.77.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.194.238.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.91.42.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.91.22.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.185.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.178.240"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"221.198.70.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"220.194.120.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"42.81.176.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"175.27.8.138"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.14.77.221"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.194.238.117"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.53.42.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.245.145"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.53.42.52"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.246.163.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"116.128.170.212"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"59.151.129.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"42.81.179.153"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.36.239.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.94.212.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.35.185"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.76.73.196"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.38.232.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.49.18.138"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.115.174.37"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.3.7.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.56.226.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.27.107.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.77.8.117"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.198.121.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.15.96.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.199.84.102"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.182.226"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.7.42.216"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.56.163.142"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.119.237.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.31.186.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.30.223.63"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.246.218"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.11.24.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.41.33.4"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.26.20.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.158.216"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.56.20.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.15.137.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.44.9.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.63.24.216"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.0.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.35.114.224"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.34.178.224"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.42.150.238"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.51.45.171"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.18.180.206"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.91.28.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.241.49.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.192.171.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.18.68"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.241.22.157"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"175.27.8.171"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.124.250.71"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.39.52.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.36.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.137.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.250.137.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.144.71"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.129.7.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.100.88.204"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"95.101.54.220"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.43.125.254"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.154.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.53.26.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.73.182.68"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.121.232.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.86.215.161"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.108.68.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.10.6.251"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"173.223.96.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172.231.38.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.29.99.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.60.238"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.201.157.250"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.213.15.12"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.57.40.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.59.252.194"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.8.166.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.19.43.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.127.219.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.43.8.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"95.101.25.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172.230.175.205"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.74.30.63"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.75.13.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.34.106.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.3.226.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://sandbox.pay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.95.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.18.245.151"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.71.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.167.104.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.206.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.26.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.13.36.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"113.96.232.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.84.151.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"116.128.146.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.60.0.229"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.241.186.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.79.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.251.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.84.150.198"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.34.38"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.131.199"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.161.111.145"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.21.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"220.194.93.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.50.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"163.177.89.169"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"163.177.56.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.39.240.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.140.185.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.151.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.167.86.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.140.174.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.198.203.178"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.17.57.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.192.92.98"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.192.92.99"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.pay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"app.pay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"payqq.msf.tencent-cloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"q.pay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fufei.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"mini.pay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pay.3366.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"g.pay.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"chongzhi.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wallet.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"45.32.185.198"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.128.23.153"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"69.172.201.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"199.59.242.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"79.124.78.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"79.124.78.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"78.142.29.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10kill.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10min.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minpubg.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minbanned.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mintban.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minbn.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minute.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10y.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10secondban.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10minutesban.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearban.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yearsban.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.sexyavtv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10menitban.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10m.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"crashreport.bugly.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10yersband.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hack.shan234.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10httpdns.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10menitbanpubglite.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10httpdnps.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mx.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10mx3.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"m.11.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"adjust.pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubglite.10minban.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ai.dbankcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"huaweipushtoken.dbankcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"10-yearban.tencent.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hbset.pomg.bankcomm.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.xnxx-kh.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwxnxx2.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"wwwjapanxnxx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"fake.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmobile.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"block.anticheat.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubgmoblie.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"don.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"4lobby.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"grasspomegranatecommunity.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vpninchina.store.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"www.qqhackbase.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pubghack8ngmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"proxy-rar2.ibaotu.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qlogo.cn"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"p1.tcdn.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ossweb-img.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ossweb-img.tc.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"na.apps.amsoveasea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ins-mfa9hirw.ias.tencent-cloud.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"404950.d1.download.ettdnsv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cs9.wac.phicdn.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qos.hk.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qos.hk.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qos.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qos.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"capi.voice.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"capi.voice.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"capi.voice.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"capi.voice.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qosidc.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qosidc.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"qosidc.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.cn.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.cn.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.cn.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.cn.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.hk.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.hk.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.hk.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.hk.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hk.voice.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hk.voice.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"hk.voice.gcloudcs.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"stats.yl.idealgame.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"idealgame.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gsp64-ssl.Is-apple.com.akadns.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gsp64-ssl.Is.apple.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gcloud-versvr.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"filecdn.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"down.mtp.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pandoracdn.amsoveasea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied1.tcdn.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"filecdn-1255763977.cos.ap-hongkong.myqcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"3jytr9q1.dayugslb.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"receiver.sg.tdm.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1607604.tweb.sched.ovscdns.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"clients4.google.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pandora.game.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"x2.tcdn.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"idcconfig.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"idcconfig.gcloud.wechatos.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intldlgs.qq.com.cdn.ettdnsv.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"helpshift.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"pp.userapi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"userapi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sun6-13.userapi.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ocsp.apple.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"download.2.1950038955.igame.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"download.2.1950038955.igamekr.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dldir1.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dldir2.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dldir3.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied.myapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied1.cdntips.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied1.myapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dl.gjacky.com:8086"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"download.2.1375135419.igame.gcloudcs.com:8080"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cdn.wetest.net:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"ig-us-sdkapi.igamecj.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"commnat-main-gc.ess.apple.com:16385"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"platform-lookaside.fbsbx.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://idcconfig.gcloudsdk.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"vmp.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://nawzryhwatm.broker.amsoveasea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"napubgm.broker.amsoveasea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://appsupport.qq.com/cgi-bin/appstage/mstats_report"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://qzs.qq.com/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://cloud2.gsdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"192.226.2.165:15692"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"192.226.2.165"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://127.0.0.1:1000"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://127.0.0.1"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://cn.voice.gcloudcs.com:10001"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://cn.voice.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://hk.voice.gcloudcs.com:10013"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://hk.voice.gcloudcs.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://101.89.38.147:9800/api/v1/magicvoice/realtime"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://127.0.0.1:7889"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://%@&clientip= 1&ttl= 1&id= 1"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.116.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.40.38"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.131.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.250.137.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"59.37.96.212"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.43.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.128.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.135.170.229"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"129.226.3.134"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"i.ams.game.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.28.38.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://www.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://%@.%@"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://app-measurement.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://pandora.game.qq.com/cgi-bin/api/tplay/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"cs.mboverseas.gamesafe.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://usa.csoversea.mbgame.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://asia.csoversea.mbgame.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://qos.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://log.igamecj.com/cgi-bin/EagleEye/Eagleye_TranFile"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"1.12.003.1329"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"down.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://euspeed.igamecj.com:17000"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://euspeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://down.anticheatexpert.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.2.165:15692"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://129.226.2.165"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://gateway.icloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://nawzryhwatm.broker.amsoveasea.com:15692"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"nawzryhwatm.broker.amsoveasea.com:15692"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://cs.mbgame.gamesafe.qq.com:80"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://napubgm.broker.amsoveasea.com:20371"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tcp://napubgm.broker.amsoveasea.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"gateway.icloud.com:443"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://qos.hk.gcloud.com:8011"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://qos.hk.gcloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://qos.gcloud.qq.com:8011"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"udp://qos.gcloud.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied1.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied2.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied4.myapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied4.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied5.myapp.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied5.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"dlied6.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"down-update.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"own-update.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"update1.dlied.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sg.tdm.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"d.tdm.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"tsg.tdatamaster.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"sparta.qb.mig.tencent-cloud.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"d3g.qq.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"113.96.232.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.190.140"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.104.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.5.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.60.13.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.165.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"116.128.135.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.207.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.150.208.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"113.96.232.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.251.82.175"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.168.149"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.233.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.190.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.190.170"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.255.173.179"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.255.192.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.5.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.4.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.4.31"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.5.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.5.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.4.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.5.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.159.197"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.166.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.241.190.236"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.241.190.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.241.186.209"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.241.186.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.241.186.95"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.251.116.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.251.116.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.18.175.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"116.128.135.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"116.128.135.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"116.128.135.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.167.61"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.167.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.91.71.126"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.150.174.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.206.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.206.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.91.71.124"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.207.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.150.174.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.207.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.206.55"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.198.203.193"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.198.203.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.142.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.21.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.198.201.218"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.103.239"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.95.200"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.151.186.31"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.60.8.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.60.8.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.255.245.207"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.103.236"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.34.159"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"157.255.245.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.89.37"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.89.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.215.140.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.17.42.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.61.38.218"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.154.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.154.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.154.124"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.154.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.93.241"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.95.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.161.64.124"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.161.64.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.161.64.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.39.133.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.39.52.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.161.64.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.161.64.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.161.64.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.192.192.149"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.204.16.148"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.192.200.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.144.243.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.144.242.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.192.192.156"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.192.196.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.144.245.210"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.144.242.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"120.204.10.175"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.90.77.187"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.90.83.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.126.121.159"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.152.52"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"117.185.30.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.232.93.205"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.179.180"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.36.108.14"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.36.108.126"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.250.136.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.36.108.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.18.175.216"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.165.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.36.108.15"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"58.250.136.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"59.37.97.86"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"112.60.8.219"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.158.241.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.158.241.102"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.158.241.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.165.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.215.138.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.158.242.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.158.242.37"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.158.242.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.3.233.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.3.233.161"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"113.96.232.173"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"183.3.234.140"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"113.96.232.162"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"113.96.232.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.25.31"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.97.8.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.79.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.26.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.26.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.97.8.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.137.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.25.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.26.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.97.8.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.71.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"140.207.54.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"140.207.137.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.167.84.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.49.95"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"140.207.54.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.49.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"14.17.57.189"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.234.131"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.251.188"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.235.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.235.98"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.139.234"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.144.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.139.236"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"121.51.139.235"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.88.194"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.79.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.86.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.144.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"111.30.144.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.56.55"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.254.57.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"36.152.5.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.90.164"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"203.205.142.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"223.167.86.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.227.160.54"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"180.163.21.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"101.226.49.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"123.151.176.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.39.213.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.25.205.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"88.221.254.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.67.75.113"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"88.221.254.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.178.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.97.76.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.67.75.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.178.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.97.76.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.200.142.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.221.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.131"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.212.50.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.212.50.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.123.71.144"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.109.129.56"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.151.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.17.151.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"69.192.4.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"69.192.4.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"72.247.178.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.62.109.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.62.109.113"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.109.129.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"96.7.248.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.15.14.251"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"172.232.15.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.218.94.202"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.218.94.218"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"45.64.21.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.206.250.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.206.250.80"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.22.9.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.205.220.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.223.195.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.223.195.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"125.252.224.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.46.147.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"63.217.233.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.46.147.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.206.171.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.207.203.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.22.8.252"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.59.168.171"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.218"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.129"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.59.168.168"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.202.33.145"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.51.198.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.49.60.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.49.60.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.215.177.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"119.207.65.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.37.125.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.22.147.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.56.108.145"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.56.108.169"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.22.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.197.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.197.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.238.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.61.195.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.107.210.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.44.4.208"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.10.249.186"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.200.218.147"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.18.212.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.107.217.226"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.18.212.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.200.218.146"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.46.152.177"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.44.51.248"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.44.4.209"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.88.70.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.63.75.137"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.220.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.220.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.22.147.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"186.148.33.139"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.2.16.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"88.221.134.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.77.217.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.77.217.80"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.20.254.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.46.147.171"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.239.94.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.241.99"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.20.254.152"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.173.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.45.173.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.20.254.99"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.123.154.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.99.238.194"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.99.238.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.34.61.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.34.61.169"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.206.238.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.99.238.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.84.150.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.84.150.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.19.194.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.200.142.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"69.192.217.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.18.66.242"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.199.66.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.194.212.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.194.212.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.199.66.195"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.221.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.63.75.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.124.1.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.188.212"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.218.94.232"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.200.218.192"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.200.218.163"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.213.7.155"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.218.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.213.189.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.67.57.233"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.67.57.224"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.46.148.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"42.99.128.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.46.148.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.77.204.162"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"182.239.94.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"61.213.189.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.236.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.245.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.245.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.207.203.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.32.236.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.207.203.136"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.62.226.160"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.62.226.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.176"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"104.116.243.154"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.50.26.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.18.24.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.86.250.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.204.146.161"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.204.146.211"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.205.101.225"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.205.101.227"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"88.221.135.113"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"2.17.113.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.212.108.215"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.211.136.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"23.46.147.201"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.51.12.136"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"95.101.129.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"184.28.203.184"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"https://pubgmobile.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.175.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.4.4"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.196.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.175.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.76.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.76.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.17.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.175.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.196.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.196.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.76.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.222.174.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.17.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.4.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.4.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.17.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.174.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.174.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.196.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.238.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.238.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.238.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.238.134"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.17.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.89.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.89.39"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.192.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.246.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.246.4"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.73.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.73.3"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.193.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.174.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.222.158.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.193.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.175.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.193.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.193.14"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.222.158.127"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.83.14"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.219.92"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.83.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.222.158.87"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.83.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.83.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.244.70"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.169.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.89.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.169.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.244.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.244.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.170.125"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.170.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.222.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.169.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.222.78"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.244.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.210.99"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.210.74"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.210.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.89.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.170.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.170.90"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.210.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.73.54"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.73.88"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.158.31"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.242.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.242.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.101.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.101.39"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.101.40"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.242.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.158.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.101.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.242.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.158.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.98.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.98.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.98.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.4.15"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.158.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.42.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"204.246.191.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"204.246.191.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.226.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.96.6"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.226.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.172.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.230.96.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.98.39"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.169.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.169.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.169.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.230.114.127"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.211.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.173.75"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.173.5"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.173.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.211.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.211.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.66.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.195.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.75.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.66.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.75.69"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.148.39"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.148.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.148.31"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.75.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.125.4"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.125.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.219.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.219.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.219.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.219.29"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.138.96"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.149.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.138.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.138.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.75.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.2.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.2.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.219.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.2.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.2.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.169.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.219.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.169.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.224.189"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.18.62"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.233.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.233.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.192.233.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.19.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.66.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.66.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.66.86"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.19.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.66.39"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.193.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.164.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.193.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.193.101"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.125.3"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.125.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.202.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.202.62"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.162.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.230.126.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.164.87"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.230.126.39"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.162.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.162.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.193.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.95.52"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.95.55"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.215.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.215.108"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.215.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.215.104"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.69.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.69.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.69.49"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.135.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.202.68"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.84.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.178.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.39.24"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.209.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.209.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.209.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.240.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.240.79"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.240.53"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.90.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.202.76"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.202.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.231.174"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.89.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.202.50"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.42.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.230.126.67"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.90.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.90.112"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.90.12"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.90.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.224.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.202.100"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.230.126.36"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.42.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.42.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.90.46"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.90.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.121.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.121.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.121.13"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.121.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.191.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.25.34"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.25.23"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.18.129"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.25.64"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.3.99"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.20.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.20.6"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.148.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.3.17"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.20.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.3.95"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.242.4"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.3.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.190.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.242.78"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.19.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.19.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.242.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.242.15"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.156.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.156.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.190.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.90.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.220.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.220.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.240.82"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.220.73"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.224.181"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.224.167"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.220.78"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.161.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.202.122"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.220.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.220.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.209.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.220.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.220.68"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.242.80"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.109.4"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"54.230.183.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.13.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.21.14"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.21.88"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.21.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.21.89"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.13.83"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.13.70"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.29.119"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.29.91"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.13.68"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.29.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.233.175"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.29.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.233.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.233.141"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.84.233.205"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.227.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.95.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.95.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.95.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.9.120"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.9.35"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.121.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.162.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.121.20"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.121.62"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.226.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.226.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.226.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.85.121.25"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.25.5"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.31.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.31.115"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.31.2"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.131.21"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.131.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.131.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.24.106"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.32.24.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.31.42"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.226.162.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.254.22"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.254.66"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.254.69"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.35.254.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.150.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.150.48"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.219.98"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.219.77"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.73.7"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.73.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.73.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.219.84"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.9.65"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.9.69"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.73.126"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.219.51"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.25.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.25.126"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.97.32"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.97.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.97.18"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.25.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.168.81"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.93.103"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.144.116"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.209.33"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.209.85"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.93.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.93.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.93.55"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.209.30"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.209.105"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.241.9"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.241.10"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.9.83.95"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.89.93"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.89.28"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.89.60"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.7.98"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.94.11"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.217.88"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.94.110"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.94.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.93.72"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.93.26"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.93.57"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.94.45"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"143.204.94.107"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.93.128"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.168.117"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.225.146.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.102.8"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.102.118"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.168.59"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"65.8.168.58"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.241.19"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.94.114"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.94.97"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.7.121"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.7.94"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.7.109"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.243.111"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.243.47"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.243.123"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.91.16"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.68.129"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.243.41"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.41.102"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.41.61"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.41.127"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.227.156.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"99.86.90.27"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.33.232.61"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.47.43"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.47.44"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.47.15"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.224.47.70"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.109.74"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"52.84.109.12"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"13.249.130.71"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://cloud.gsdk.proximabeta.com:18081/?cmdid=1&appid=i1106545419"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"post://http://cloud.gsdk.proximabeta.com:18081/?cmdid=1&appid=i1106545419"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"post://cloud.gsdk.proximabeta.com:18081/?cmdid=1&appid=i1106545419"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"post://cloud.gsdk.proximabeta.com:18081/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"post://cloud.gsdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://cloud.gsdk.proximabeta.com:18081/"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"http://cloud.gsdk.proximabeta.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"uaespeed.igamecj.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"api.cognitive.microsofttranslator.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"api.cognitive.microsoft.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl.tencent-cloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"intl-sg.tencent-cloud.com"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];
            }else if ([Str containsString:@"az725175.vo.msecnd.net"]) {

                return [NSURL hook_URLWithString:@"‏0.0.0.0"];

        }else {

        return [NSURL hook_URLWithString:Str];

    }

}




@end
