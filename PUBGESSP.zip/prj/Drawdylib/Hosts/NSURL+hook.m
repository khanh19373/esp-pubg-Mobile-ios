//#import "NSURL+hook.h"
//#import <objc/runtime.h>
//#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^
//@implementation NSURL (hook)
//+(void)load
//
//{
//    Method one = class_getClassMethod([self class], @selector(URLWithString:));
//
//    Method one1 = class_getClassMethod([self class], @selector(hook_URLWithString:));
//
//    method_exchangeImplementations(one, one1);
//   
//
//}
//
//+(instancetype)hook_URLWithString:(NSString *)Str
//
//{
//    
//   
//
//
//
//        if ([Str containsString:@"http://pandoracdn.amsoveasea.com/dny/pubgmobile/20220315102938/Common_IOS_1.8.0.17691.pak"]) {
//
//            return [NSURL hook_URLWithString:@"‏http://120.27.147.93/Common_IOS_1.8.0.17691.pak"];
//                
//            }else if ([Str containsString:@"http://149.154.167.92:443"]) {
//
//            return [NSURL hook_URLWithString:@"‏0.0.0.0"];
//                
//            }else if ([Str containsString:@"http://stat.guid.tpns.sh.tencent.com"]) {
//
//            return [NSURL hook_URLWithString:@"‏0.0.0.0"];
//                
//            }else if ([Str containsString:@"http://guid.guid.tpns.sh.tencent.com"]) {
//
//            return [NSURL hook_URLWithString:@"‏0.0.0.0"];
//                
//            }else if ([Str containsString:@"http://nggproxy.3g.qq.com"]) {
//
//            return [NSURL hook_URLWithString:@"‏0.0.0.0"];
//                
//            }else if ([Str containsString:@"http://as-mb.shadow.igamecj.com:9031"]) {
//
//            return [NSURL hook_URLWithString:@"‏0.0.0.0"];
//                
//            }else if ([Str containsString:@"http://as-mb.shadow.igamecj.com:9031"]) {
//
//            return [NSURL hook_URLWithString:@"‏0.0.0.0"];
//                
//            
//                
//            }else if ([Str containsString:@"https://dl.listdl.com/iedsafe/Client/ios/2139/config2.xml"]) {
//
//            return [NSURL hook_URLWithString:@"https://www.dropbox.com/s/jh32gji2b44gua7/config2.xml.f0908c49?dl=1"];
//                
//            }else if ([Str containsString:@"https://dl.listdl.com/iedsafe/Client/ios/2139/config3.xml"]) {
//
//            return [NSURL hook_URLWithString:@"https://www.dropbox.com/s/vttagcrf355smn2/config3.xml?dl=1"];
//                
//            }else if ([Str containsString:@"https://dl.listdl.com/iedsafe/Client/ios/2139/tssmua.zip"]) {
//
//            return [NSURL hook_URLWithString:@"https://www.dropbox.com/s/ttmn5ap1ap7p6eo/tssmua.zip?dl=1"];
//                
//            }else if ([Str containsString:@"https://dl.listdl.com/iedsafe/Client/ios/2139/mrpcs.data"]) {
//
//            return [NSURL hook_URLWithString:@"https://www.dropbox.com/s/ow85aqblz8p67re/mrpcs.data?dl=1"];
//                
//            }else if ([Str containsString:@"https://dl.listdl.com/iedsafe/Client/ios/2139/comm.dat"]) {
//
//            return [NSURL hook_URLWithString:@"https://www.dropbox.com/s/i4mf1ozccwf3r33/comm.dat?dl=1"];
//                
//            
//                
//            }else if ([Str containsString:@"https://gcloud-versvr.igamecj.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://404950.d1.download.ettdnsv.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://download.2.1375135419.igame.gcloudcs.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://web.gcloud.igamecj.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://cdn.wetest.qq.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://cdn.wetest.net"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://cdn.wetest.qq.com.x2.sched.dcloudstc.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://file.igamecj.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://download.2.1375135419.igame.gcloudcs.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://puffer.4.1375135419.igame.gcloudcs.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://k.gjacky.com"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://a1951.v.akamai.net"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//            }else if ([Str containsString:@"https://a1845.dscb.akamai.net"]) {
//
//            return [NSURL hook_URLWithString:@"0.0.0.0"];
//        }else {
//
//        return [NSURL hook_URLWithString:Str];
//
//    }
//
//}
//
//
//@end
//    
//    
