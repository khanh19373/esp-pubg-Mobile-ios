
//

#import <Foundation/Foundation.h>
#import "NSEtcHosts.h"
#import <UIKit/UIKit.h>

@implementation NSObject(hook)


//自带功能+(void)


//+(void) Hosts{//自带
-(void)hosts{//调用hosts
    [NSURLProtocol registerClass:[EtcHostsURLProtocol class]];
//    [EtcHostsURLProtocol configureHostsWithBlock:^(id <EtcHostsConfiguration> configuration) {
//        [configuration resolveHostName:@"dlied1.qq.com;dlied2.qq.com;dlied3.qq.com;dlied4.qq.com;dlied5.qq.com;dlied6.qq.com" toIPAddress:@"132.232.173.228"];
//    }];
    
    
    [EtcHostsURLProtocol configureHostsWithBlock:^(id <EtcHostsConfiguration> configuration) {
        [configuration resolveHostName:@"down.anticheatexpert.com" toIPAddress:@"119.29.29.29"];
    }];//单个ip
    
    
    ///////////////////////////
    
    
    
    
        [EtcHostsURLProtocol configureHostsWithBlock:^(id <EtcHostsConfiguration> configuration) {
            [configuration resolveHostName:@"*:17500;nggproxy.3g.qq.com;szmg.qq.com;cs.mbgame.gamesafe.qq.com;down.anticheatexpert.com;dlied6.qq.com" toIPAddress:@"119.29.29.29"];
        }];//多个ip
    
    
    //////////////////////////////////////////////
    //调用hosts成功弹窗
    
    
        UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"VEGAS" message:@"GO" preferredStyle:UIAlertControllerStyleAlert];
    
        [alertCtrl addAction:[UIAlertAction actionWithTitle:@"❌关闭❌" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    //[NSObject caidan];
        }]];

        [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];
    
    
}





@end
