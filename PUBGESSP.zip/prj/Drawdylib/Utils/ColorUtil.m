////
////  ColorUtil.m
////  GIFT
////
////  Created by Trần Hải Linh on 3/21/14.
////  Copyright (c) 2014 GIFT. All rights reserved.
////
//
//#import "ColorUtil.h"
//#import "Macro.h"
//
//@implementation ColorUtil
//
//+ (UIColor*) getButtonRedColor
//{
//     return [self colorFromHexString:@"#e74c3c"]; // RGB: 231 76 60
//};
//
//+ (UIColor *)redColorDefault
//{
//    return [self colorFromHexString:@"#FE7167"]; // RGB: 254 113 103
//}
//+ (UIColor *)pinkColorDefault
//{
//    return [self colorFromHexString:@"#FFAAA0"]; // RGB: 255 170 160
//}
//+ (UIColor *)colorGray
//{
//    return [self colorFromHexString:@"#6D6F71"]; // RGB: 109 111 113
//}
//
//+ (UIColor*) getButtonYellowColor
//{
//    return [self colorFromHexString:@"#FCC884"]; // RGB: 252 200 132
//};
//
//+ (UIColor*) getButtonPinkColor
//{
//    return [self colorFromHexString:@"#F39CA1"]; // RGB: 243 156 161
//};
//
//+ (UIColor*) getNavigationBarRedColor
//{
//    return [self colorFromHexString:@"#e74c3c"]; // RGB: 231 76 60
//    
////    return [self colorFromHexString:@"#fafbfb"]; // RGB: 236 240 241
//};
//
//+ (UIColor*) getNavigationBarYellowColor
//{
//    return [self colorFromHexString:@"#ecf0f1"]; // RGB: 255 242 220
//};
//
//+ (UIColor*) getTabbarWhiteColor
//{
//    return [self colorFromHexString:@"#ecf0f1"]; // RGB: 255 242 220
//};
//
//+ (UIColor *)getTextViewGreenColor
//{
//    return [self colorFromHexString:@"#3665AE"]; // RGB: 54 101 174
//};
//
//+ (UIColor *)getBackgroundColor
//{
//    return [UIColor whiteColor];
//}
//
//+ (UIColor *)getBackgroundListviewColor {
//    return RGB(242, 238, 234);
//}
//
//+ (UIColor*)getGrayDefault {
//    return [self colorFromHexString:@"#F8F8F8"];
//}
//
//+ (UIColor*)getLightGreyDefault {
//    return [self colorFromHexString:@"#CCCCCC"];   // RGB: 204 204 204
//}
//
//+ (UIColor*)getSeparatorColorDefault {
//    return [self colorFromHexString:@"#F1EEEA"];   // RGB: 241 238 234
//
//}
//
//+(UIColor *)colorFromHexString:(NSString *)hexString {
//    unsigned rgbValue = 0;
//    NSScanner *scanner = [NSScanner scannerWithString:hexString];
//    [scanner setScanLocation:1]; // bypass '#' character
//    [scanner scanHexInt:&rgbValue];
//    return [UIColor colorWithRed:((rgbValue & 0xFF0000) >> 16)/255.0 green:((rgbValue & 0xFF00) >> 8)/255.0 blue:(rgbValue & 0xFF)/255.0 alpha:1.0];
//}
//
//+ (UIColor *)getBlackColorDefault {
//    return [self colorFromHexString:@"#333333"];  //RGB: 51 51 51
//}
//
//@end
