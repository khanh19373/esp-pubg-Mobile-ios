//
//  ColorUtil.h
//  GIFT
//
//  Created by Trần Hải Linh on 3/21/14.
//  Copyright (c) 2014 GIFT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ColorUtil : NSObject

+ (UIColor*) getButtonRedColor;

+ (UIColor *)redColorDefault;

+ (UIColor *)pinkColorDefault;

+ (UIColor *)colorGray;

+ (UIColor*) getButtonYellowColor;

+ (UIColor*) getButtonPinkColor;

+ (UIColor*) getNavigationBarRedColor;

+ (UIColor*) getNavigationBarYellowColor;

+ (UIColor*) getTabbarWhiteColor;

+ (UIColor *) getTextViewGreenColor;

+ (UIColor *)getBackgroundColor;

+ (UIColor *) colorFromHexString:(NSString *)hexString;

+ (UIColor *)getBackgroundListviewColor;

+ (UIColor*)getGrayDefault;

+ (UIColor*)getLightGreyDefault;

+ (UIColor*)getSeparatorColorDefault;

+ (UIColor*)getBlackColorDefault;

@end
