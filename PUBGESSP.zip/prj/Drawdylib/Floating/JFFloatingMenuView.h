
#import <UIKit/UIKit.h>
#import "JFFloatingView.h"

NS_ASSUME_NONNULL_BEGIN

@interface JFFloatingMenuView : JFFloatingView

@end

NS_ASSUME_NONNULL_END
