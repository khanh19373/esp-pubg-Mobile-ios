
#import <UIKit/UIKit.h>
#import "UIView+YYAdd.h"
#import "JFCommon.h"

NS_ASSUME_NONNULL_BEGIN

@interface JFDragableView : UIView

@end

NS_ASSUME_NONNULL_END
