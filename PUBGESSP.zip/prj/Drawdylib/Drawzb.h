#import <UIKit/UIKit.h>
#import "Drawst.h"
#import <Foundation/Foundation.h>
@class JFPlayer, JFProps, JFPlayerPool, JFPropsPool;

@interface IFuckYou : NSObject

@property (nonatomic, assign) bool isFire;
@property (nonatomic, assign) bool isOpenScope;


@property (nonatomic, assign) bool Gunads;

//@property (nonatomic, assign) bool isFire;

//  Created BY ？和 on 2021/6/31
//  B.Y QQ  3556674785
//  仅供学习交流，请在24小时内卸载
//  ？和
@property (nonatomic, assign) bool Shoot;


@property (nonatomic, strong) JFPlayer *localPlayer;
@property (nonatomic, strong) NSMutableArray *playerList;
@property (nonatomic, strong) NSMutableArray *propsList;

@property (nonatomic, assign) kaddr lockActor;

@property (nonatomic, strong) JFPlayerPool *playerPool;
@property (nonatomic, strong) JFPropsPool *propsPool;

@property (nonatomic, strong) JFOverlayView *overlayView;
@property (nonatomic, strong) JFFloatingMenuView *floatingMenuView;

+ (IFuckYou *)getInstance;


- (void)entry;

- (void)cancelTimer;

@end
@interface Login : NSObject
+ (void)Lifand:(bool)Swspd;
@end
