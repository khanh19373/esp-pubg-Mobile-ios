

#import <Foundation/Foundation.h>

@interface ZJHURLProtocol : NSURLProtocol

/// 开始监听
+ (void)startMonitor;

/// 停止监听
+ (void)stopMonitor;

@end
