#import <Foundation/Foundation.h>
#import "UIKit/UIKit.h"
#import "SaveData.h"

@interface Login : NSObject
+ (void)Lifand:(bool)Swspd;
@end