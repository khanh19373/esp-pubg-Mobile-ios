
//

#import <Foundation/Foundation.h>

@interface ZJHSessionConfiguration : NSObject

@property (nonatomic,assign) BOOL isSwizzle;

+ (ZJHSessionConfiguration *)defaultConfiguration;

/**
 *  swizzle NSURLSessionConfiguration's protocolClasses method
 */
- (void)load;

/**
 *  make NSURLSessionConfiguration's protocolClasses method is normal
 */
- (void)unload;

@end
