#import "ZJHURLProtocol.h"
#import "ZJHSessionConfiguration.h"

// 为了避免canInitWithRequest和canonicalRequestForRequest的死循环
static NSString *const kProtocolHandledKey = @"kProtocolHandledKey";

@interface ZJHURLProtocol () <NSURLConnectionDelegate,NSURLConnectionDataDelegate, NSURLSessionDelegate>

@property (nonatomic, strong) NSURLSessionDataTask *dataTask;
@property (nonatomic, strong) NSOperationQueue     *sessionDelegateQueue;
@property (nonatomic, strong) NSURLResponse        *response;

@end

@implementation ZJHURLProtocol

#pragma mark - Public

/// 开始监听
+ (void)startMonitor {
    ZJHSessionConfiguration *sessionConfiguration = [ZJHSessionConfiguration defaultConfiguration];
    [NSURLProtocol registerClass:[ZJHURLProtocol class]];
    if (![sessionConfiguration isSwizzle]) {
        [sessionConfiguration load];
    }
}

/// 停止监听
+ (void)stopMonitor {
    ZJHSessionConfiguration *sessionConfiguration = [ZJHSessionConfiguration defaultConfiguration];
    [NSURLProtocol unregisterClass:[ZJHURLProtocol class]];
    if ([sessionConfiguration isSwizzle]) {
        [sessionConfiguration unload];
    }
}

#pragma mark - Override

/**
 需要控制的请求
 
 @param request 此次请求
 @return 是否需要监控
 */
+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    // 拦截所有
   
    if (![request.URL.scheme isEqualToString:@"ssl.msdk.qq.com"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"thirdwx.qlogo.cn"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"down.anticheatexpert.com"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"hpjy-op.tga.qq.com"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"nggproxy.3g.qq.com"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"down.qq.com"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"q1.qlogo.cn"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"*:17500"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"*:8081"]) {
        return YES;
    }
    if (![request.URL.scheme isEqualToString:@"*:8085"]) {
        return YES;
    }
    return YES;
}

/**
 设置我们自己的自定义请求
 可以在这里统一加上头之类的
 
 @param request 应用的此次请求
 @return 我们自定义的请求
 */
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request {
    NSMutableURLRequest *mutableReqeust = [request mutableCopy];
    // 设置已处理标志
    [NSURLProtocol setProperty:@(YES)
                        forKey:kProtocolHandledKey
                     inRequest:mutableReqeust];
    return [mutableReqeust copy];
}

// 重新父类的开始加载方法
/*- (void)startLoading {
    //  NSLog(@"***ZJH 监听接口：%@", self.request.URL.absoluteString);
    NSDictionary *chickenjson = @{@"Action":@"NEW_RESPONSE_09_21_41",@"Enabled":@"false",@"Headers":@"SFRUUC8xLjEgMzA3IEF1dG9SZWRpcg0KQ29udGVudC1MZW5ndGg6IDANCkxvY2F0aW9uOiBodHRwczovL2RsaWVkMS5xcS5jb20vaWVkc2FmZS9DbGllbnQvaW9zLzIxMzEvQjU1ODlDNjAvbXJwY3MuZGF0YQ0KQ2FjaGUtQ29udHJvbDogbWF4LWFnZT0wLCBtdXN0LXJldmFsaWRhdGUNCg0K"};
    NSData *redirectData =[NSJSONSerialization dataWithJSONObject:chickenjson options: 0 error:NULL];
    NSURLResponse *redirectresponse = [[NSURLResponse alloc] initWithURL:self.request.URL
                                                                MIMEType:@"application/json"
                                                   expectedContentLength:redirectData.length
                                                        textEncodingName:nil];
    [[self client] URLProtocol:self didReceiveResponse:redirectresponse cacheStoragePolicy:NSURLCacheStorageAllowed];
    [self.client URLProtocol:self didLoadData:redirectData];
    [self.client URLProtocolDidFinishLoading:self];
}*/

// 结束加载
- (void)stopLoading {
    [self.dataTask cancel];
}
@end
