//
//  Created BY ？和 on 2021/6/31
//  B.Y QQ  3556674785
//  仅供学习交流，请在24小时内卸载￼

#pragma mark - 调用文件
#import "Drawst.h"
#import "Drawzb.h"
#import "Drawlm.h"
#import "Drawdk.h"
#import "JFPlayerPool.h"
#import "JFPropsPool.h"
#import "JFCommon.h"
#import "Color.h"
#import "imgui.h"
#import "imgui_internal.h"
#import "ImGuiWrapper.h"
#import "ImGuiStyleWrapper.h"
#import "TextEditorWrapper.h"
#import "GuiRenderer.h"
#import "HeeeNoScreenShotView.h"
#import "Utils/ColorUtil.h"
#import "mahoa.h"
#import "FCUUID.h"

#define iPhone8P ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)
using namespace std;
std::string string_format(const std::string &fmt, ...) {
    std::vector<char> str(100,'\0');
    va_list ap;
    while (1) {
        va_start(ap, fmt);
        auto n = vsnprintf(str.data(), str.size(), fmt.c_str(), ap);
        va_end(ap);
        if ((n > -1) && (size_t(n) < str.size())) {
            return str.data();
        }
        if (n > -1)
            str.resize( n + 1 );
        else
            str.resize( str.size() * 2);
    }
    return str.data();
}



@interface JFOverlayView () <GuiRendererDelegate> {
    ImFont *_espFont;
}

@property (nonatomic, strong) MTKView *mtkView;
@property (nonatomic, strong) GuiRenderer *renderer;
@property (nonatomic, strong) GuiRenderer *Ttime;



@end
UIWindow *Esp;
HeeeNoScreenShotView *HideEsp;



static bool lineaimplayer = false;


@implementation JFOverlayView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        
        
        self.isStartTimer = false;
        self.isShowMenu = false;
        self.isLineEsp = false;
        self.isBoneEsp = false;
        self.isHpBarEsp = false;
        self.isTextEsp = false;
        self.isBoxEsp = false;
        self.isAimbot = false;
        self.isAimbotS = false;
        self.isAimbotF = false;
        self.isAimbotA = false;
        
        
        self.aimlockp = false;
        
        self.nolockb = false;

        self.isBulletTrack = false;
        self.isNorecoil = false;
        self.isNearDeathNotAim = false;
        self.isAINotAim = false;
        
        self.isShowProps = false;
        self.isShowPropsVehicle = false;
        self.isShowPropsWeapon = false;
        self.isShowPropsArmor = false;
        self.isShowPropsSight = false;
        self.isShowPropsEarlyWarning = false;
        
        self.FastSwitchWeapon = false;
        self.anti = false;
        
        self.BPc = false;
        self.BoxWith = false;
        self.Pistol = false;
        self.isTeamMateEsp = false;
        
        
        self.propsDistance = 300;
        self.aimbotPart = 4;
        self.aimbotRadius = 150;
        self.espDistance = 300;
        

        
        
        
        
        






- (void)setupUI
{
    self.mtkView = [[MTKView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.mtkView.backgroundColor = [UIColor clearColor];
    [[UIApplication sharedApplication].keyWindow addSubview:self.mtkView];
    self.mtkView.device = MTLCreateSystemDefaultDevice();
    if (!self.mtkView.device) {
        return;
    }
    
    self.renderer = [[GuiRenderer alloc] initWithView:self.mtkView];
    self.renderer.delegate = self;
    self.mtkView.delegate = self.renderer;
    [self.renderer initializePlatform];
}


#pragma mark - GuiRendererDelegate
- (void)setup
{
    ImGuiIO & io = ImGui::GetIO();
    ImFontConfig config;
    config.FontDataOwnedByAtlas = false;
   // ImGui::StyleColorsLight();
    
    NSString *fontPath = @"/System/Library/Fonts/Core/HelveticaNeue.ttc";
       _espFont = io.Fonts->AddFontFromFileTTF(fontPath.UTF8String, 40.f, &config, io.Fonts->GetGlyphRangesVietnamese());
    
}


- (void)draw
{

        [self drawOverlay];
        [self drawMenu];
    }

}

#pragma mark - 绘制

- (void)drawMenu
{
    self.userInteractionEnabled = self.isShowMenu;
    self.mtkView.userInteractionEnabled = self.isShowMenu;
    if (!_isShowMenu) {
        return;
    }
    
    HeeeNoScreenShotView *noScreenShotView = [[HeeeNoScreenShotView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
    
     [noScreenShotView setUserInteractionEnabled:NO];
           
    [[[[UIApplication sharedApplication] windows]lastObject] addSubview:noScreenShotView];
    
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        
        
        CGFloat width = SCREEN_WIDTH * 0.5;
        CGFloat height = SCREEN_HEIGHT * 0.5;
        
        if (SCREEN_WIDTH > SCREEN_HEIGHT) {
            
            height = SCREEN_HEIGHT * 0.5;
            
        } else {
            
            width = SCREEN_WIDTH * 0.5;
        }
        
        HideEsp = [[HeeeNoScreenShotView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        HideEsp.userInteractionEnabled = NO;
        Esp = [UIApplication sharedApplication].keyWindow;
        [Esp addSubview:HideEsp];

        
        ImGuiIO & io = ImGui::GetIO();
        
        io.DisplaySize = ImVec2(width, height);
        
            ImGui::SetNextWindowPos(ImVec2((SCREEN_WIDTH - width) * 0.5, (SCREEN_HEIGHT - height) / 3), 0, ImVec2(0, 0));
            ImGui::SetNextWindowSize(ImVec2(370, 250));
        }
        

        
        
        
      //  io.FontGlobalScale = 0.3f;
    });
    
    //static bool an_hack = false;
    
    

    
    


    
         
    ImGui::Begin("hack", &_isShowMenu, ImGuiWindowFlags_NoResize |                 ImGuiWindowFlags_NoCollapse);
    if (ImGui::BeginTabBar("Tab", ImGuiTabBarFlags_NoTooltip))
    {


            if (ImGui::BeginTabItem("Chức Năng"))
                    {
                        ImGui::Text("Chức năng ESP");
                        ImGui::Checkbox("Vẽ ESP", &_isStartTimer); ImGui::SameLine();
                        ImGui::Checkbox("Kẻ Chỉ", &_isLineEsp); ImGui::SameLine();
                        ImGui::Checkbox("Xương", &_isBoneEsp);
                        ImGui::Checkbox("Tên", &_isTextEsp); ImGui::SameLine();
                        ImGui::Checkbox("Máu", &_isHpBarEsp); ImGui::SameLine();
                        ImGui::Checkbox("Hộp", &_isBoxEsp);
                        ImGui::Spacing();

                        ImGui::SliderInt("Vùng ESP", &_espDistance, 0, 500);
                        
                        ImGui::Spacing();
                        
                        if (ImGui::Button("Ẩn Hack"))
                        {
                       [HideEsp addSubview:_mtkView];
                            

                            }
                        }
                        
                        
                        
     /*
                        ImGui::TextColored(ImColor(16, 43, 106), "Material Options");
                        ImGui::Checkbox("Material", &_isShowProps); ImGui::SameLine();
                        ImGui::Checkbox("Vehicle", &_isShowPropsVehicle); ImGui::SameLine();
                        ImGui::Checkbox("Weapon", &_isShowPropsWeapon); ImGui::SameLine();
                        ImGui::Checkbox("Armor", &_isShowPropsArmor); ImGui::SameLine();
                        ImGui::Checkbox("Scope", &_isShowPropsSight); ImGui::SameLine();
                        ImGui::Spacing();
                        ImGui::Checkbox("Accessory", &_isShowPropsAccessory); ImGui::SameLine();
                        ImGui::Checkbox("Bullet", &_isShowPropsBullet); ImGui::SameLine();
                        ImGui::Checkbox("Drug", &_isShowPropsDrug);ImGui::SameLine();
                        ImGui::Spacing();

                        ImGui::Checkbox("Pistol", &_Pistol); ImGui::SameLine();
                        ImGui::Checkbox("Grenade warning", &_isShowPropsEarlyWarning); ImGui::SameLine();
                        ImGui::Checkbox("Knock out boxes", &_BoxWith); ImGui::SameLine();
                        ImGui::Checkbox("Show Airdrop", &_BPc); ImGui::SameLine();
                        */


                 ImGui::EndTabItem();
                 
             }
        }
        

        

            if (ImGui::BeginTabItem("Aimbot"))
              {

              ImGui::Text("Aimbot");
              ImGui::Checkbox("Aimbot", &_isAimbot); ImGui::SameLine();
                  if(_isAimbot){
                      ImGui::SliderInt("FOV", &_aimbotRadius, 10, 500);
                  }
                  
                  
              ImGui::Checkbox("Kẻ chỉ địch đang Aim", &lineaimplayer);
                          
                  
              ImGui::Checkbox("Khoá địch", &_aimlockp);ImGui::SameLine();
                  
              ImGui::Checkbox("Bỏ qua Bot", &_nolockb);
                  
                  
                  
            //  ImGui::Spacing();
                  
                  
                  
              ImGui::Text("Nơi Aim");
              ImGui::RadioButton("Đầu", &_aimbotPart, 6); ImGui::SameLine();
              ImGui::RadioButton("Cổ", &_aimbotPart, 5); ImGui::SameLine();
                  ImGui::RadioButton("Ngực", &_aimbotPart, 4);ImGui::SameLine();
                  ImGui::RadioButton("Chân", &_aimbotPart, 2);
                  
            //  ImGui::Spacing();
                  
                  
           //   ImGui::Spacing();
              ImGui::EndTabItem();
                  
                  }
        }
        
        
  
        
       /*
        
        if (ImGui::BeginTabItem("Cài Đặt"))
        {
            
        ImGui::Spacing();
            

      

       
      

            
            
           ImGui::Spacing();
        ImGui::EndTabItem();

        }
        
        */
        


        ImGui::EndTabBar();
        }

        ImGui::End();
        }



- (void)drawOverlay
{
    
    
    
    
    
    
    if (!self.isStartTimer) {
        return;
    }
    
    if (self.isAimbot || self.isBulletTrack) {
        
        for (JFPlayer *player in [IFuckYou getInstance].playerList)
            if (player.isVisible){
                [self drawAimRangeWithCenter:ImVec2(SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.5) radius:self.aimbotRadius color:Color::White numSegments:100 thicknes:0.01f];

            }else{
                [self drawAimRangeWithCenter:ImVec2(SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.5) radius:self.aimbotRadius color:Color::White numSegments:100 thicknes:0.01f];

            }
        
    }
    int enemyCount = 0;
    for (JFPlayer *player in [IFuckYou getInstance].playerList) {
        if (player.type == PlayerTypeEnemy) {
            enemyCount++;
        }
    }
    
    [self playerCountEsp:enemyCount];
    
    for (JFPlayer *player in [IFuckYou getInstance].playerList) {
        
        if (player.isDead || (player.type == PlayerTypeTeam && !self.isTeamMateEsp)) {
            continue;
        }
        
        Color color = Color::White;

            if (player.isVisible) {
                color = Color::White;
            } else {
                color = Color::White;
            }
        /*
        if (player.type == PlayerTypeEnemy && player.isFallDown) {
            color = Color::Xue2;
        }
         */
        
        if ((self.isAimbot || self.isBulletTrack) && player.isBestAimTarget) {
            
            [self drawCircleFilledWithCenter:ImVec2(player.box.origin.x + player.box.size.width * 0.5, player.box.origin.y + player.box.size.height * 0.5) radius:3 color:Color::Blue numSegments:20];
            
            
            if(lineaimplayer){
            [self drawLineWithStartPoint:ImVec2(SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.5) endPoint:ImVec2(player.box.origin.x + player.box.size.width * 0.5, player.box.origin.y + player.box.size.height * 0.5) color:Color::White thicknes:0.1];
                color = Color::Green;
            }

            
            
        }
        
      
        if (self.isHpBarEsp) {
            [self hpBarEsp:player];
            


            }
            
        }
  
        if (self.isTextEsp) {
            [self textEsp:player distanceColor:color];
            


            }
        }
        
        if (self.isBoxEsp) {
     
            [self drawRectWithPos:ImVec2(player.box.origin.x, player.box.origin.y) size:ImVec2(player.box.size.width, player.box.size.height) color:color thicknes:1];
            

                exit(0);
            }
        }
      
        if (self.isLineEsp) {
            float offset = 5;
            
            if (self.isHpBarEsp) {
                offset += 10;
            }
            
            if (self.isTextEsp) {
                offset += 20;
            }
            
            [self drawLineWithStartPoint:ImVec2(SCREEN_WIDTH * 0.5, 10) endPoint:ImVec2(CGRectGetMidX(player.box), CGRectGetMinY(player.box) - offset) color:color thicknes:0.1];
        }
        
        if (self.isBoneEsp) {
            [self boneEsp:player];
        }
    }
    for (JFProps *props in [IFuckYou getInstance].propsList) {
        
        if (props.type == PropsTypeWeapon && self.isShowPropsWeapon) {
            [self propsEsp:props color:Color::Quan];
        }
        
        if (props.type == Flaregun && self.Pistol) {
            [self propsEsp:props color:Color::Quan];
        }
        
        if (props.type == PropsTypeArmor && self.isShowPropsArmor) {
            [self propsEsp:props color:Color(238, 238, 0)];
        }
        
        if (props.type == PropsTypeSight && self.isShowPropsSight) {
            [self propsEsp:props color:Color(238, 238, 0)];
        }
        
        if (props.type == PropsTypeAccessory && self.isShowPropsAccessory) {
            [self propsEsp:props color:Color(238, 238, 0)];
        }
        
        if (props.type == PropsTypeBullet && self.isShowPropsBullet) {
            [self propsEsp:props  color:Color::Green];
        }
        
        if (props.type == PropsTypeDrug && self.isShowPropsDrug) {
            [self propsEsp:props color:Color::Yao];
        }
        
        if (props.type == PickUpListWrapperActor && self.BoxWith) {
            [self propsEsp:props color:Color::Yao];
        }
        
        if (props.type == AirDropBox && self.BPc) {
            [self propsEsp:props color:Color::Yao];
        }
        
        if (props.type == PropsTypeVehicle && self.isShowPropsVehicle) {
            [self propsEsp:props color:Color::Che];
        }
        
        if (props.type == PropsTypeEarlyWarning && self.isShowPropsEarlyWarning) {
            
            [self propsEsp:props color:Color::Red];
            
            if (props.distance <= 10) {
                
                [self drawTextWithText:props.name pos:ImVec2(SCREEN_WIDTH * 0.5, 65) isCentered:true color:Color::Red outline:true fontSize:25];
                
                [self drawLineWithStartPoint:ImVec2(SCREEN_WIDTH * 0.5, 55) endPoint:ImVec2(props.screenPos.X, props.screenPos.Y) color:Color::Blue thicknes:0.1];
            }
        }
    }
    
}

- (void)propsEsp:(JFProps *)props color:(Color)color
{
    [self drawTextWithText:string_format("%s👮‍♂️ [%dm]", props.name.c_str(), props.distance)
                       pos:ImVec2(props.screenPos.X, props.screenPos.Y)
                isCentered:true
                     color:color
                   outline:false
                  fontSize:15];
    
}

- (void)playerCountEsp:(int)count
{
    for (JFPlayer *player in [IFuckYou getInstance].playerList)
        if (player.isVisible){
            [self drawTextWithText:string_format("ENEMIES %d", count)
                               pos:ImVec2(SCREEN_WIDTH * 0.5, 25)
                        isCentered:true
                             color:Color::Green
                           outline:true
                          fontSize:16];
        }else{
            [self drawTextWithText:string_format("ENEMIES %d", count)
                               pos:ImVec2(SCREEN_WIDTH * 0.5, 25)
                        isCentered:true
                             color:Color::Green
                           outline:true
                          fontSize:16];
            
        }
}

- (void)hpBarEsp:(JFPlayer *)player
{
    /*
    float rate = 1.0f * player.hp / player.maxHp;
    float width = 80;
    float height = 7;
    
    float width1 = 80;
    float height1 = 13;
    
    
    //
    float width = 90;
    float height = 12;
    //

    float x = CGRectGetMidX(player.box) - width1 * 0.5;
    float y = CGRectGetMinY(player.box) - height1 - 14;
       
    float x1 = CGRectGetMidX(player.box) - width * 0.5;
    float y1 = CGRectGetMinY(player.box) - height - 12;
    
    
    
    Color color=Color::Green;
    if(player.isAI==true)
    {
         color = Color::Green;
    }else{
        
        color =Color::Red;
    }

    
    [self drawRectFilledWithPos:ImVec2(x1, y1) size:ImVec2(width, height) color:Color::White];
    
    [self drawRectFilledWithPos:ImVec2(x1, y1) size:ImVec2(width * rate, height) color:color];
    
    [self drawRectFilledWithPos:ImVec2(x, y) size:ImVec2(width1, height1) color:Color::Black];
    
    */
    
    float rate = 1.0f * player.hp / player.maxHp;
    // float width = 120;
    float width = 100;
    // float height = 5;
    float height = 1.5;
    float x = CGRectGetMidX(player.box) - width * 0.5;
    // float y = CGRectGetMinY(player.box) - height - 5;
    float y = CGRectGetMinY(player.box) - height - 7;
    
    
    
    ImVec2 vec[3];
    vec[0] = ImVec2(x+45,y+2);
    vec[1] = ImVec2(x+50,y+7);
    vec[2] = ImVec2(x+55,y+2);
    Color colorT = Color::Red;
    colorT.a = 0.5 * 255;
    
    ImGui::GetBackgroundDrawList()->AddConvexPolyFilled(vec, 3, [self getImU32:colorT]);
    
    Color color = Color::White;
    
    if (rate < 0.35) {
        color = Color::Red;
    } else if (rate < 0.75) {
        color = Color::Orange;
        
    }
    color.a = 0.7*255;
    [self drawRectFilledWithPos:ImVec2(x, y) size:ImVec2(width * rate, height) color:Color::White];
    
    

}

-(UIColor*)colorWithHex:(NSUInteger)hex
                  alpha:(CGFloat)alpha
{
    float r, g, b, a;
    a = alpha;
    b = hex & 0x0000FF;
    hex = hex >> 8;
    g = hex & 0x0000FF;
    hex = hex >> 8;
    r = hex;

    return [UIColor colorWithRed:r/255.0f
                           green:g/255.0f
                           blue:b/255.0f
                           alpha:a];
}



- (void)textEsp:(JFPlayer *)player distanceColor:(Color)distanceColor
{


//NSUInteger colorArray[] = {0x333333,0x333366,0x336633,0x336633,0x339999,0x33CCCC,0x663333,0x663366,0x663366,0x999933,0xCC3366,0xCC6666,0xCC6633,0xFF9966,0x660066};

   //   UIColor *color = [self colorWithHex:colorArray[player.teamNo % (sizeof(colorArray)/8)] alpha:0.6];
    
    
    float width1 = 80;
    float height1 = 12;
    
    
    float x1 = CGRectGetMidX(player.box) - width1 * 0.5;
    float y1 = CGRectGetMinY(player.box) - height1 - 15;

    float teamNoWidth = 20;
    
    
    
    
    
    float width = 100;
    float height = 14;
    float x = CGRectGetMidX(player.box) - width * 0.5;
    float y = CGRectGetMinY(player.box) - height - 10;
    //Color colorTeamNumber =Color(colorArray[player.teamNo % (sizeof(colorArray)/4)],0.5*255);
    Color colorTeamNumber =Color::rrtt;
    
    
    /*
    //Color colorTeam;
    if (player.isAI) {
        colorTeam =Color::Red;
    }else{
        colorTeam =Color::Red;
    }
     */
    Color color=Color::greendam;
    Color color1=Color::greendamx2;
    if(player.isAI==true)
    {
         color = Color::greendam;
        color1 =Color::greendamx2;
    }else{
        
        color =Color::reddam;
        color1 =Color::reddamx2;
    }
    
    
    [self drawRectFilledWithPos:ImVec2(x, y) size:ImVec2(width, height) color:color];
    [self drawRectFilledWithPos:ImVec2(x, y) size:ImVec2(teamNoWidth, height) color:color1];
    
    [self drawTextWithText:string_format("%d", player.teamNo)
                       pos:ImVec2(x + teamNoWidth * 0.5, y+4)
                isCentered:true
                     color:Color::White
                   outline:false
                  fontSize:9];
    
        
    
    NSMutableString *name;
    if(player.hp <= 0){
        name = [NSMutableString stringWithString:@"Knocked Down"];
    }else{
        name = [NSMutableString stringWithCString:player.name.c_str() encoding:NSUTF8StringEncoding];
        if (player.isAI) {
            name = [NSMutableString stringWithString:@"Bot"];
        }
    }
    
    
    /*
    
        NSMutableString *name = [NSMutableString stringWithCString:player.name.c_str() encoding:NSUTF8StringEncoding];
    if (player.isAI) {
        name =[NSMutableString stringWithString:@"Bot"];
    }
     
     */
     
    [self drawTextWithText:name.UTF8String
                       pos:ImVec2(x + teamNoWidth + 3, y + 4)
                isCentered:false
                     color:Color::White
                   outline:false
                  fontSize:9];
    
    
    
    
    
    /*
    

    
    
    [self drawTextWithText:string_format("%d", player.teamNo)
                       pos:ImVec2(x+11, y-9)
                isCentered:true
                     color:Color::Green
                   outline:true
                  fontSize:9];
    }

    
    //name.length() = 10;

    string name;
    if(player.hp <= 0){
        name = string_format("Knocked Down");
    }else{
         name = string_format("%s", player.name.c_str());
        if (player.isAI) {
             name = string_format("Bot");
        }
    }
    
    
    
    
    [self drawTextWithText:name
                       pos:ImVec2(CGRectGetMidX(player.box), y+1.2)
                      // pos:ImVec2(CGRectGetMidX(player.box) - (name.length()/2), y)
                isCentered:true
                     color:Color::White
                   outline:false
                  fontSize:11];
    
    
    
    */

    string distance = string_format("[%dM]", player.distance);

    [self drawTextWithText:distance
                       pos:ImVec2(CGRectGetMidX(player.box), y1-7)
                isCentered:true
                     color:Color::White
                   outline:true
                  fontSize:9];
    
    

    

}
- (void)boneEsp:(JFPlayer *)player
{
   
    Color invisibleColor = Color::Red;
    Color visibleColor = Color::Green;

    float thicknes = 0.1;
    
    [self drawCircleFilledWithCenter:ImVec2(player.boneData.head.X, player.boneData.head.Y) radius:CGRectGetWidth(player.box) * 0.13f color:player.boneVisibleData.head ? visibleColor : invisibleColor  numSegments:15];
    

    //[self drawCircleFilledWithCenter:ImVec2(player.box.origin.x + player.box.size.width * 0.5, player.box.origin.y + player.box.size.height * 0.5) radius:3 color:Color::Red numSegments:20];

    
    
    
    [self drawLineWithStartPoint:ImVec2(player.boneData.head.X, player.boneData.head.Y+7) endPoint:ImVec2(player.boneData.chest.X, player.boneData.chest.Y) color:player.boneVisibleData.chest ? visibleColor : invisibleColor thicknes:thicknes];
    
    
    [self drawLineWithStartPoint:ImVec2(player.boneData.chest.X, player.boneData.chest.Y) endPoint:ImVec2(player.boneData.pelvis.X, player.boneData.pelvis.Y) color:player.boneVisibleData.chest ? visibleColor : invisibleColor thicknes:thicknes];
    
    [self drawLineWithStartPoint:ImVec2(player.boneData.chest.X, player.boneData.chest.Y) endPoint:ImVec2(player.boneData.leftShoulder.X, player.boneData.leftShoulder.Y) color:player.boneVisibleData.chest ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.chest.X, player.boneData.chest.Y) endPoint:ImVec2(player.boneData.rightShoulder.X, player.boneData.rightShoulder.Y) color:player.boneVisibleData.chest ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.leftShoulder.X, player.boneData.leftShoulder.Y) endPoint:ImVec2(player.boneData.leftElbow.X, player.boneData.leftElbow.Y) color:player.boneVisibleData.leftShoulder ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.rightShoulder.X, player.boneData.rightShoulder.Y) endPoint:ImVec2(player.boneData.rightElbow.X, player.boneData.rightElbow.Y) color:player.boneVisibleData.rightShoulder ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.pelvis.X, player.boneData.pelvis.Y) endPoint:ImVec2(player.boneData.leftThigh.X, player.boneData.leftThigh.Y) color:player.boneVisibleData.pelvis ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.pelvis.X, player.boneData.pelvis.Y) endPoint:ImVec2(player.boneData.rightThigh.X, player.boneData.rightThigh.Y) color:player.boneVisibleData.pelvis ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.leftElbow.X, player.boneData.leftElbow.Y) endPoint:ImVec2(player.boneData.leftHand.X, player.boneData.leftHand.Y) color:player.boneVisibleData.leftElbow ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.rightElbow.X, player.boneData.rightElbow.Y) endPoint:ImVec2(player.boneData.rightHand.X, player.boneData.rightHand.Y) color:player.boneVisibleData.rightElbow ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.leftThigh.X, player.boneData.leftThigh.Y) endPoint:ImVec2(player.boneData.leftKnee.X, player.boneData.leftKnee.Y) color:player.boneVisibleData.leftThigh ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.rightThigh.X, player.boneData.rightThigh.Y) endPoint:ImVec2(player.boneData.rightKnee.X, player.boneData.rightKnee.Y) color:player.boneVisibleData.rightThigh ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.leftKnee.X, player.boneData.leftKnee.Y) endPoint:ImVec2(player.boneData.leftFoot.X, player.boneData.leftFoot.Y) color:player.boneVisibleData.leftKnee ? visibleColor : invisibleColor thicknes:thicknes];
    [self drawLineWithStartPoint:ImVec2(player.boneData.rightKnee.X, player.boneData.rightKnee.Y) endPoint:ImVec2(player.boneData.rightFoot.X, player.boneData.rightFoot.Y) color:player.boneVisibleData.rightKnee ? visibleColor : invisibleColor thicknes:thicknes];
}


- (void)drawAimRangeWithCenter:(ImVec2)center radius:(float)radius color:(Color)color numSegments:(int)numSegments thicknes:(float)thicknes
{
    ImGui::GetOverlayDrawList()->AddCircle(center, radius, [self getImU32:color], numSegments, thicknes);
}
- (void)drawLineWithStartPoint:(ImVec2)startPoint endPoint:(ImVec2)endPoint color:(Color)color thicknes:(float)thicknes
{
    ImGui::GetBackgroundDrawList()->AddLine(startPoint, endPoint, [self getImU32:color], thicknes);
}

- (void)drawCircleWithCenter:(ImVec2)center radius:(float)radius color:(Color)color numSegments:(int)numSegments thicknes:(float)thicknes
{
    ImGui::GetBackgroundDrawList()->AddCircle(center, radius, [self getImU32:color], numSegments, thicknes);
}

- (void)drawCircleFilledWithCenter:(ImVec2)center radius:(float)radius color:(Color)color numSegments:(int)numSegments
{
    ImGui::GetBackgroundDrawList()->AddCircleFilled(center, radius, [self getImU32:color], numSegments);
}
- (void)drawTextWithText:(string)text pos:(ImVec2)pos isCentered:(bool)isCentered color:(Color)color outline:(bool)outline fontSize:(float)fontSize
{
    const char *str = text.c_str();
    ImVec2 vec2 = pos;
    if (isCentered) {
        ImVec2 textSize = _espFont->CalcTextSizeA(fontSize, MAXFLOAT, 0.0f, str);
        vec2.x -= textSize.x * 0.5f;
    }//qq654153159
    if (outline)
    {
        ImU32 outlineColor = [self getImU32:Color::Black];//
        ImGui::GetBackgroundDrawList()->AddText(_espFont, fontSize, ImVec2(vec2.x + 1, vec2.y + 1), outlineColor, str);
        ImGui::GetBackgroundDrawList()->AddText(_espFont, fontSize, ImVec2(vec2.x - 1, vec2.y - 1), outlineColor, str);
        ImGui::GetBackgroundDrawList()->AddText(_espFont, fontSize, ImVec2(vec2.x + 1, vec2.y - 1), outlineColor, str);
        ImGui::GetBackgroundDrawList()->AddText(_espFont, fontSize, ImVec2(vec2.x - 1, vec2.y + 1), outlineColor, str);
    }
    ImGui::GetBackgroundDrawList()->AddText(_espFont, fontSize, vec2, [self getImU32:color], str);
}

- (void)drawRectWithPos:(ImVec2)pos size:(ImVec2)size color:(Color)color thicknes:(float)thicknes
{
    ImGui::GetBackgroundDrawList()->AddRect(pos, ImVec2(pos.x + size.x, pos.y + size.y), [self getImU32:color], 0, 0, thicknes);
}
- (void)drawRectWithPos1:(ImVec2)pos size:(ImVec2)size color:(Color)color thicknes:(float)thicknes
{
    ImGui::GetBackgroundDrawList()->AddRect(pos, ImVec2(pos.x + size.x, pos.y + size.y), [self getImU32:color], 20, ImDrawCornerFlags_All, thicknes);
}

- (void)drawRectFilledWithPos:(ImVec2)pos size:(ImVec2)size color:(Color)color
{
    ImGui::GetBackgroundDrawList()->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), [self getImU32:color], 0, 0);
}
- (void)drawRectFilledWithPosBoGoc:(ImVec2)pos size:(ImVec2)size color:(Color)color
{
    ImGui::GetBackgroundDrawList()->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), [self getImU32:color], 20, ImDrawCornerFlags_All);
}

- (void)drawRectFilledWithPosBoGoc1:(ImVec2)pos size:(ImVec2)size color:(Color)color
{
    ImGui::GetBackgroundDrawList()->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), [self getImU32:color], 20, ImDrawCornerFlags_All);
}

- (void)drawRectFilledWithPosTronGoc:(ImVec2)pos size:(ImVec2)size color:(Color)color
{
    ImGui::GetBackgroundDrawList()->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), [self getImU32:color], 0, 0);
    
    
}


- (ImU32)getImU32:(Color)color
{
    return ((color.a & 0xff) << 24) + ((color.b & 0xff) << 16) + ((color.g & 0xff) << 8) + (color.r & 0xff);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.renderer handleEvent:event view:self];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.renderer handleEvent:event view:self];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.renderer handleEvent:event view:self];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.renderer handleEvent:event view:self];
}

@end
