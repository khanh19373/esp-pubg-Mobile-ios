#import "JFObjectPool.h"
@class JFProps;

NS_ASSUME_NONNULL_BEGIN

@interface JFPropsPool : JFObjectPool

@property (nonatomic, strong) JFProps *player;

@end

NS_ASSUME_NONNULL_END
