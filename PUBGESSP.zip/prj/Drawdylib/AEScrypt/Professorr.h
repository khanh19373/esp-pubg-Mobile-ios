//
//  md5.h
//  key
//
//  Created by mac on 3/22/21.
//  Copyright © 2021 mac. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DREM : NSObject
@property (nonatomic , strong)NSString * vll;




+ (NSString *)dec:(NSString *)ecom;
+ (unsigned long long )decoff:(NSString *)offset;
+ (void )hala_Patch : (NSString *)offset : (NSString *)byte;


@end

NS_ASSUME_NONNULL_END

